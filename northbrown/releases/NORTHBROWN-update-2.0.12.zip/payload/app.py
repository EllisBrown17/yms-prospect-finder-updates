from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess, sys, tempfile, urllib.request, zipfile

ROOT = Path(__file__).resolve().parent
UPDATES = ROOT / 'data' / 'updates'
BASE = '2.0.11'
TARGET = '2.0.12'
CORE = ('app.py','feature_routes.py','builder_routes.py','requirements.txt','templates/index.html','static/app.js','static/app.css','design_dna_engine.py','smart_scan_engine.py','VERSION.txt')
PARTS = [f'p{i}.b64' for i in range(5)]
RAW = 'https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.12/'
FULL_SIZE = 16000
FULL_SHA = '96d038eaa6344969645982aca044a5b50df2ac9efd65063978db1fea12ca19f2'


def backup():
    b = UPDATES / 'backups'
    found = []
    if b.exists():
        for p in b.iterdir():
            try:
                if p.is_dir() and (p/'VERSION.txt').read_text(encoding='utf-8').strip() == BASE:
                    if all((p/r).exists() for r in ('app.py','feature_routes.py','builder_routes.py','templates/index.html','static/app.js','static/app.css','VERSION.txt')):
                        found.append(p)
            except Exception:
                pass
    if not found:
        raise RuntimeError('No valid updater-created NORTHBROWN 2.0.11 backup was found.')
    return max(found, key=lambda p: p.stat().st_mtime)


def restore_and_relaunch(b):
    try:
        for r in CORE:
            s = b / r
            if s.exists():
                d = ROOT / r
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, d)
        for n in ('_nb212_migrate.py','chatgpt_import_engine.py','ui_patch_212.js','ui_patch_212.css'):
            try:
                p = ROOT / n
                if n == 'chatgpt_import_engine.py' and (b/n).exists():
                    shutil.copy2(b/n, p)
                elif p.exists():
                    p.unlink()
            except Exception:
                pass
        launcher = Path.home() / 'Applications' / 'NORTHBROWN Lead Engine.app'
        cmd = f'sleep 3; open {json.dumps(str(launcher))}' if launcher.exists() else f'sleep 3; bash {json.dumps(str(ROOT/"START_NORTHBROWN_INTERNAL.sh"))}'
        subprocess.Popen(['bash','-lc',cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except Exception:
        pass


def download_full(tmp):
    chunks = []
    for name in PARTS:
        req = urllib.request.Request(RAW + name, headers={'User-Agent':'NORTHBROWN-2.0.12-recovery'})
        with urllib.request.urlopen(req, timeout=15) as r:
            chunks.append(r.read().strip())
    try:
        raw = base64.b64decode(b''.join(chunks), validate=True)
    except Exception as e:
        raise RuntimeError('2.0.12 staged payload Base64 verification failed.') from e
    if len(raw) != FULL_SIZE:
        raise RuntimeError(f'2.0.12 staged payload size mismatch ({len(raw)} vs {FULL_SIZE}).')
    got = hashlib.sha256(raw).hexdigest()
    if got != FULL_SHA:
        raise RuntimeError('2.0.12 staged payload SHA-256 verification failed.')
    zpath = tmp / 'NORTHBROWN-update-2.0.12-full.zip'
    zpath.write_bytes(raw)
    with zipfile.ZipFile(zpath) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f'2.0.12 staged ZIP integrity check failed at {bad}.')
        required = ('payload/app.py','payload/chatgpt_import_engine.py','payload/ui_patch_212.js','payload/ui_patch_212.css')
        missing = [n for n in required if n not in zf.namelist()]
        if missing:
            raise RuntimeError('2.0.12 staged payload is incomplete.')
        for n in required:
            out = ROOT / ('_nb212_migrate.py' if n == 'payload/app.py' else Path(n).name)
            out.write_bytes(zf.read(n))
    subprocess.run([sys.executable,'-m','py_compile',str(ROOT/'_nb212_migrate.py'),str(ROOT/'chatgpt_import_engine.py')], check=True, capture_output=True, text=True)


def main():
    b = backup()
    tmp = Path(tempfile.mkdtemp(prefix='nb212-recovery-', dir=str(UPDATES)))
    try:
        download_full(tmp)
        if os.getenv('NORTHBROWN_TRANSITION_TEST') == '1':
            print('NORTHBROWN_2_0_12_RECOVERY_STAGE_OK')
            return
        os.execv(sys.executable, [sys.executable, str(ROOT/'_nb212_migrate.py')])
    except Exception:
        restore_and_relaunch(b)
        raise
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

if __name__ == '__main__':
    main()
