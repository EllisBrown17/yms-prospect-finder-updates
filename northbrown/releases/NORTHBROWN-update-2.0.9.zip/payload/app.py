# NORTHBROWN 2.0.9 Design DNA OTA bridge.
from pathlib import Path
import base64, gzip, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from urllib.request import Request, urlopen
ROOT=Path(__file__).resolve().parent; UPDATES=ROOT/'data'/'updates'
TARGET='2.0.9'; BASE='2.0.8'; MARKER=UPDATES/'northbrown-2.0.9-design-dna.done'
CORE=('app.py','feature_routes.py','builder_routes.py','requirements.txt','templates/index.html','static/app.js','static/app.css')
STAGING='https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.9/'
PARTS=['dna00.b64', 'dna01.b64', 'dna02.b64', 'dna03.b64']; GZ_SHA='c05fda2f902fb29406b704db993b4c609538cba3e55e1c7736ed3b5879081cdc'; OVERLAY_SHA='6b03096253dbf8f0f4a5b821a4b164924208463afebfd7c8f9503a79408e69cc'
def find_backup():
    found=[]; root=UPDATES/'backups'
    if root.exists():
        for p in root.iterdir():
            try:
                if p.is_dir() and (p/'VERSION.txt').read_text(encoding='utf-8').strip()==BASE and (p/'app.py').stat().st_size>50000 and (p/'builder_routes.py').stat().st_size>50000: found.append(p)
            except Exception: pass
    if not found: raise RuntimeError('Could not find the updater-created NORTHBROWN 2.0.8 backup. No migration was committed.')
    return sorted(found,key=lambda p:p.stat().st_mtime,reverse=True)[0]
def fetch_overlay():
    encoded=''
    for name in PARTS:
        req=Request(STAGING+name,headers={'User-Agent':'NORTHBROWN-OTA/2.0.9','Cache-Control':'no-cache'})
        with urlopen(req,timeout=20) as r: encoded+=r.read().decode('ascii').strip()
    gz=base64.b64decode(encoded,validate=True)
    if hashlib.sha256(gz).hexdigest()!=GZ_SHA: raise RuntimeError('Design DNA transport verification failed. No files were changed.')
    raw=gzip.decompress(gz)
    if hashlib.sha256(raw).hexdigest()!=OVERLAY_SHA: raise RuntimeError('Design DNA payload verification failed. No files were changed.')
    return raw.decode('utf-8')
def patch_builder(text,overlay):
    if '# ── NORTHBROWN Design DNA v1' in text: return text
    anchor="    @app.get('/api/builder/projects')\n"
    if anchor not in text: raise RuntimeError('Could not locate the Website Builder route anchor safely.')
    text=text.replace(anchor,overlay+'\n'+anchor,1)
    if not all(x in text for x in ('DESIGN_DNA_VERSION','_ai_design_dna','_dna_enforce_diversity','_render_page = _dna_render_page','regenerate-design')): raise RuntimeError('Design DNA patch validation failed before install.')
    return text
def main():
    legacy=find_backup(); overlay=fetch_overlay(); work=Path(tempfile.mkdtemp(prefix='northbrown-209-',dir=str(UPDATES)))
    try:
        for rel in CORE:
            src=legacy/rel
            if not src.is_file(): raise RuntimeError(f'Missing preserved NORTHBROWN 2.0.8 file: {rel}')
            dst=work/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
        app=work/'app.py'; s=app.read_text(encoding='utf-8'); s,n=re.subn(r"APP_VERSION\s*=\s*(['\"])2\.0\.8\1","APP_VERSION = '2.0.9'",s,count=1)
        if n!=1: raise RuntimeError('Could not safely update the NORTHBROWN version marker from 2.0.8.')
        app.write_text(s,encoding='utf-8'); builder=work/'builder_routes.py'; builder.write_text(patch_builder(builder.read_text(encoding='utf-8'),overlay),encoding='utf-8'); (work/'VERSION.txt').write_text(TARGET+'\n',encoding='utf-8')
        subprocess.run([sys.executable,'-m','py_compile',str(app),str(work/'feature_routes.py'),str(builder)],check=True,capture_output=True)
        for rel in CORE:
            src=work/rel; dst=ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True); tmp=dst.with_suffix(dst.suffix+'.new'); shutil.copy2(src,tmp); os.replace(tmp,dst)
        (ROOT/'VERSION.txt').write_text(TARGET+'\n',encoding='utf-8'); MARKER.parent.mkdir(parents=True,exist_ok=True); MARKER.write_text(json.dumps({'installed':TARGET,'source_backup':str(legacy),'feature':'design-dna-v1'}),encoding='utf-8')
    finally: shutil.rmtree(work,ignore_errors=True)
    if os.getenv('NORTHBROWN_TRANSITION_TEST')=='1': print('NORTHBROWN_TRANSITION_TEST_OK'); return
    os.execv(sys.executable,[sys.executable,str(ROOT/'app.py')])
if __name__=='__main__': main()
