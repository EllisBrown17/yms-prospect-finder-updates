#!/usr/bin/env python3
"""YMS Prospect Finder V4.2.10 — Smart Pipeline control wiring fix.

Repairs Pause/Resume/Stop so the UI controls drive the actual 4.2.6 pipeline
engine's checkpoint/stop_requested mechanism. No lead data is reset.
"""
import os,re,sys,time,shutil
from pathlib import Path

TARGET_VERSION="4.2.10"
APP_DIR=Path(__file__).resolve().parent
if sys.platform=="darwin":
    DATA_DIR=Path.home()/"Library"/"Application Support"/"YMS Prospect Finder V3"
elif os.name=="nt":
    DATA_DIR=Path(os.getenv("APPDATA",Path.home()))/"YMS Prospect Finder V3"
else:
    DATA_DIR=Path.home()/".yms_prospect_finder_v3"
backup=None

def fail(message):
    global backup
    msg=str(message)
    try:
        DATA_DIR.mkdir(parents=True,exist_ok=True)
        (DATA_DIR/"update_restart_error.txt").write_text(msg,encoding="utf-8")
    except Exception:
        pass
    try:
        if backup and (backup/"server.py").exists() and (backup/"index.html").exists():
            shutil.copy2(backup/"server.py",APP_DIR/"server.py")
            shutil.copy2(backup/"index.html",APP_DIR/"index.html")
            os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
    except Exception:
        pass
    raise SystemExit(msg)

CONTROL_OVERRIDE=r'''
# ---------------------------------------------------------------------------
# V4.2.10 Smart Pipeline control wiring
# The V4.2.6 engine already honours job["stop_requested"] between queue submits.
# V4.2.8 accidentally wrote only a separate in-memory control flag, so the real
# pipeline never saw Pause/Stop. Route controls through the proven checkpoint path.
# ---------------------------------------------------------------------------
def _v4210_job_control(job_id, command):
    jid=str(job_id or "")
    command=str(command or "").strip().lower()
    if not jid:
        return {"ok":False,"error":"Missing job id"}
    j=_job_get(jid) or {}
    if not j:
        return {"ok":False,"error":"Job not found","id":jid}
    action=str(j.get("action") or "")
    title=str(j.get("title") or j.get("detail") or "")
    if action!="pipeline" and "smart pipeline" not in title.lower():
        return {"ok":False,"error":"This control is only available for Smart Pipeline jobs","id":jid}

    if command=="pause":
        status=str(j.get("status") or "")
        if status=="paused":
            _job_set(jid,user_control="pause",pause_requested=False,stop_requested=False)
        elif status in ("complete","stopped","failed"):
            return {"ok":False,"error":"This Smart Pipeline is no longer running","id":jid}
        else:
            # The 4.2.6 runner sees stop_requested, stops submitting new companies,
            # waits for active workers to finish/checkpoint, then enters resumable paused state.
            _v428_set_control(jid,"pause")
            _job_set(jid,user_control="pause",pause_requested=True,stop_requested=True,
                     detail="Pausing safely — active companies are finishing and saving; no new queued companies will start")

    elif command=="resume":
        status=str(j.get("status") or "")
        if status=="paused" and bool(j.get("resumable")):
            _v428_set_control(jid,"")
            _job_set(jid,user_control="",pause_requested=False,stop_requested=False,
                     detail="Resume queued — rechecking saved checkpoints")
            out=resume_progress_job(jid) or (_job_get(jid) or {})
            _job_set(jid,user_control="",pause_requested=False,stop_requested=False,
                     detail="Resuming Smart Pipeline from saved checkpoints")
            out=dict(_job_get(jid) or out or {})
            out["ok"]=True
            return out
        if status in ("running","queued"):
            # A pause may have been requested but not yet observed by the queue loop.
            # Clearing it is safe if the runner has not committed to pausing yet.
            _v428_set_control(jid,"")
            _job_set(jid,user_control="",pause_requested=False,stop_requested=False,
                     detail="Smart Pipeline continuing")
        else:
            return {"ok":False,"error":"This Smart Pipeline is not paused","id":jid}

    elif command=="stop":
        status=str(j.get("status") or "")
        if status in ("complete","stopped","failed"):
            out=dict(j);out["ok"]=True;return out
        _v428_set_control(jid,"stop")
        # This is the flag the V4.2.6 queue loop actually checks. It prevents new
        # submissions and lets already-active workers finish and checkpoint first.
        _job_set(jid,user_control="stop",pause_requested=False,stop_requested=True,status="stopping",
                 detail="Stopping safely — active companies are finishing and saving; remaining queued companies will stay untouched")
    else:
        return {"ok":False,"error":"Command must be pause, resume or stop","id":jid}

    out=dict(_job_get(jid) or {})
    out["ok"]=True
    return out

# Existing /api/job/control route resolves this global name at request time.
_v428_job_control=_v4210_job_control
'''

try:
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    backups=DATA_DIR/"update-backups"
    choices=[]
    if backups.exists():
        for p in backups.glob("before-"+TARGET_VERSION+"-*"):
            if (p/"server.py").exists() and (p/"index.html").exists():
                try: choices.append((p.stat().st_mtime,p))
                except Exception: pass
    if not choices:
        fail("V4.2.10 could not find the updater-created safe pre-update backup. Nothing was changed.")
    backup=max(choices,key=lambda x:x[0])[1]

    s=(backup/"server.py").read_text("utf-8")
    h=(backup/"index.html").read_text("utf-8")

    required=("def _v426_run_pipeline_job(","def _v428_job_control(","/api/job/control","stop_requested")
    missing=[x for x in required if x not in s]
    if missing:
        raise RuntimeError("Current runtime is missing the expected Smart Pipeline control hooks: "+", ".join(missing))

    s,n=re.subn(r'APP_VERSION\s*=\s*["\'][^"\']+["\']',f'APP_VERSION = "{TARGET_VERSION}"',s,count=1)
    if n!=1:
        raise RuntimeError("Could not update APP_VERSION")

    if "# V4.2.10 Smart Pipeline control wiring" not in s:
        marker="class Handler(SimpleHTTPRequestHandler):"
        if marker not in s:
            raise RuntimeError("Could not locate HTTP Handler for control override")
        s=s.replace(marker,CONTROL_OVERRIDE+"\n\n"+marker,1)

    # Keep the UI layout from 4.2.9; only update visible version labels.
    h=re.sub(r'Prospect Finder V4\.2\.[0-9]+',f'Prospect Finder V{TARGET_VERSION}',h)
    h=re.sub(r'YMS Prospect Finder V4\.2\.[0-9]+',f'YMS Prospect Finder V{TARGET_VERSION}',h)

    compile(s,"v4.2.10-runtime-server.py","exec")
    if "_v428_job_control=_v4210_job_control" not in s or "stop_requested=True" not in s:
        raise RuntimeError("V4.2.10 control override validation failed")

    (APP_DIR/"server.py").write_text(s,encoding="utf-8")
    (APP_DIR/"index.html").write_text(h,encoding="utf-8")
    (DATA_DIR/"last_ota_update.txt").write_text(
        TARGET_VERSION+"\n"+time.strftime('%Y-%m-%d %H:%M:%S')+"\nSmart Pipeline Pause/Resume/Stop control wiring fixed\n",
        encoding="utf-8")
except Exception as exc:
    fail(exc)

os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
