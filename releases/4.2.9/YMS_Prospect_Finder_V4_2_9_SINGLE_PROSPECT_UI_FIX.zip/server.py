#!/usr/bin/env python3
"""YMS Prospect Finder V4.2.9 — single-prospect action + scan control layout hotfix."""
import os,re,sys,time,shutil
from pathlib import Path

TARGET_VERSION="4.2.9"
APP_DIR=Path(__file__).resolve().parent
if sys.platform=="darwin": DATA_DIR=Path.home()/"Library"/"Application Support"/"YMS Prospect Finder V3"
elif os.name=="nt": DATA_DIR=Path(os.getenv("APPDATA",Path.home()))/"YMS Prospect Finder V3"
else: DATA_DIR=Path.home()/".yms_prospect_finder_v3"
backup=None

def fail(message):
    global backup
    msg=str(message)
    try:
        DATA_DIR.mkdir(parents=True,exist_ok=True)
        (DATA_DIR/"update_restart_error.txt").write_text(msg,encoding="utf-8")
    except Exception: pass
    try:
        if backup and (backup/"server.py").exists() and (backup/"index.html").exists():
            shutil.copy2(backup/"server.py",APP_DIR/"server.py")
            shutil.copy2(backup/"index.html",APP_DIR/"index.html")
            os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
    except Exception: pass
    raise SystemExit(msg)

# The updater creates a before-<target>-... backup immediately before it runs this payload.
backups=DATA_DIR/"update-backups"
choices=[]
if backups.exists():
    for p in backups.glob("before-"+TARGET_VERSION+"-*"):
        if (p/"server.py").exists() and (p/"index.html").exists():
            try: choices.append((p.stat().st_mtime,p))
            except Exception: pass
if not choices:
    fail("V4.2.9 could not find the safe pre-update backup. Nothing was changed.")
backup=max(choices,key=lambda x:x[0])[1]

JS_PATCH=r'''/* V4.2.9 single-prospect + pipeline-controls repair */
window.prospectWorkNotice = function(l){
  try{
    l=l||{}; let msg="",kind="warn";
    if(!l.ai&&l.ai_skip_reason)msg=l.ai_skip_reason;
    else if(!((l.web_evidence||{}).text)&&l.web_skip_reason)msg=l.web_skip_reason;
    if(!msg)return "";
    const e=(typeof esc==="function")?esc(msg):String(msg).replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;"}[c]));
    return `<div class="notice ${kind}" style="margin-top:9px"><b>Last attempt:</b> ${e}</div>`;
  }catch(_e){ return ""; }
};

window.runOneProspectStep = async function(action,id,title){
  try{
    if(typeof runProgressJob!=="function") throw new Error("Prospect action runner is unavailable. Refresh the page once.");
    const j=await runProgressJob(action,[id],title||"Working prospect");
    if(typeof loadLeads==="function") await loadLeads();
    if(typeof openD==="function") openD(id);
    const l=(typeof leads!=="undefined"&&Array.isArray(leads))?leads.find(x=>x.id===id):null;
    const reason=action==="web_one"?(l?.web_skip_reason||""):(l?.ai_skip_reason||l?.web_skip_reason||"");
    if(Number(j?.skipped)||reason){
      if(typeof toast==="function")toast(reason||"This step could not be completed. The reason is shown in the prospect drawer.","warn",7500);
    }else{
      if(typeof toast==="function")toast(action==="web_one"?"Website evidence updated.":"AI qualification complete — score, priority and email draft updated.","good",5200);
    }
    return j;
  }catch(e){
    try{ if(typeof loadLeads==="function")await loadLeads(); if(typeof openD==="function")openD(id); }catch(_e){}
    alert(e?.message||String(e));
  }
};

(function(){
  function txt(el){return String(el?.textContent||"").trim().toLowerCase().replace(/\s+/g," ");}
  function pipelineButtons(){
    return [...document.querySelectorAll("button")].filter(b=>{
      const t=txt(b);
      return t==="pause"||t==="resume"||t==="stop"||t==="pause scan"||t==="resume scan"||t==="stop scan";
    });
  }
  function smartPipelineAnchor(){
    return [...document.querySelectorAll("button")].find(b=>txt(b).includes("smart pipeline")&&!txt(b).includes("pause")&&!txt(b).includes("stop"));
  }
  function dockPipelineControls(){
    const buttons=pipelineButtons();
    if(!buttons.length)return;
    let dock=document.getElementById("ymsPipelineControlsDock");
    const anchor=smartPipelineAnchor();
    const origins=[...new Set(buttons.map(b=>b.parentElement).filter(Boolean))];
    if(!dock){
      dock=document.createElement("span");
      dock.id="ymsPipelineControlsDock";
      dock.setAttribute("aria-label","Smart Pipeline controls");
      dock.style.cssText="display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap;margin-left:8px;vertical-align:middle;position:relative;z-index:2;";
    }
    if(anchor){
      if(dock.parentElement!==anchor.parentElement) anchor.insertAdjacentElement("afterend",dock);
    }else if(!dock.parentElement){
      document.body.appendChild(dock);
      dock.style.cssText+="position:fixed;top:88px;right:22px;z-index:9990;background:rgba(10,18,24,.96);padding:7px;border-radius:10px;border:1px solid rgba(255,255,255,.12);box-shadow:0 8px 28px rgba(0,0,0,.28);";
    }
    buttons.forEach(b=>{
      if(b.parentElement!==dock)dock.appendChild(b);
      b.style.margin="0"; b.style.whiteSpace="nowrap";
    });
    origins.forEach(o=>{
      if(o===dock||o.contains(dock)||dock.contains(o))return;
      try{
        const cs=getComputedStyle(o),r=o.getBoundingClientRect(),t=txt(o);
        if((cs.position==="fixed"||cs.position==="absolute")&&r.width*r.height<140000&&!t.includes("live activity")&&o.querySelectorAll("button").length===0){o.style.display="none";}
      }catch(_e){}
    });
  }
  let queued=false;
  function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;dockPipelineControls();});}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",schedule,{once:true}); else schedule();
  new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener("resize",schedule,{passive:true});
})();
'''

try:
    s=(backup/"server.py").read_text("utf-8")
    h=(backup/"index.html").read_text("utf-8")

    s,n=re.subn(r'APP_VERSION\s*=\s*["\'][^"\']+["\']',f'APP_VERSION = "{TARGET_VERSION}"',s,count=1)
    if n!=1: raise RuntimeError("Could not update APP_VERSION")

    # Install the helpers globally even if an earlier broken patch left partial definitions.
    end=h.rfind("</script>")
    if end<0: raise RuntimeError("Could not locate the application JavaScript block")
    h=h[:end]+"\n"+JS_PATCH+"\n"+h[end:]

    # Keep visible version labels current without touching unrelated content.
    h=re.sub(r'Prospect Finder V4\.2\.[0-9]+',f'Prospect Finder V{TARGET_VERSION}',h)

    compile(s,"v4.2.9-runtime-server.py","exec")
    required=("window.runOneProspectStep","window.prospectWorkNotice","ymsPipelineControlsDock")
    if not all(x in h for x in required): raise RuntimeError("Frontend hotfix validation failed")

    shutil.copy2(backup/"server.py",backup/"server.py.v429-original") if not (backup/"server.py.v429-original").exists() else None
    (APP_DIR/"server.py").write_text(s,encoding="utf-8")
    (APP_DIR/"index.html").write_text(h,encoding="utf-8")
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    (DATA_DIR/"last_ota_update.txt").write_text(
        TARGET_VERSION+"\n"+time.strftime('%Y-%m-%d %H:%M:%S')+"\nSingle-prospect AI + non-overlapping Smart Pipeline controls hotfix installed\n",
        encoding="utf-8")
except Exception as exc:
    fail(exc)

os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
