import os,sys,base64,hashlib,zipfile,tempfile,urllib.request,subprocess,time
from pathlib import Path
VERSION='4.2.0'
REPO='https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/payloads/4.2.0'
ROOT=Path(__file__).resolve().parent
IS_WIN=os.name=='nt'
PREFIX='win' if IS_WIN else 'mac'
PARTS=5
SHA='eb9bc77d4a29d482a14e1dae1fc58192ba5fec406760b81c02c61e735b7a8210' if IS_WIN else '2f24c14f6670f8eeeccdb7e08de95a49539c11090a8866fc87dec6da80e28568'

def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'YMS-Prospect-Finder-Updater/4.2'})
    with urllib.request.urlopen(req,timeout=30) as r:return r.read()

def install():
    print('YMS Prospect Finder 4.2.0 — finishing OTA install...')
    b64=b''
    for i in range(PARTS):
        url=f'{REPO}/{PREFIX}.{i:02d}'
        print(f'Downloading update part {i+1}/{PARTS}...')
        b64+=get(url).strip()
    data=base64.b64decode(b64)
    got=hashlib.sha256(data).hexdigest()
    if got.lower()!=SHA.lower():raise RuntimeError(f'Update verification failed: {got}')
    tmp=Path(tempfile.mkdtemp(prefix='yms-v420-'))/'update.zip';tmp.write_bytes(data)
    with zipfile.ZipFile(tmp) as z:
        names=z.namelist()
        if 'server.py' not in names or 'index.html' not in names:raise RuntimeError('Update package is incomplete')
        z.extractall(ROOT)
    print('V4.2.0 installed successfully. Restarting...')

def relaunch():
    if IS_WIN:
        bat=ROOT/'Start YMS Prospect Finder.bat'
        if bat.exists():
            subprocess.Popen(['cmd','/c','start','',str(bat)],cwd=str(ROOT));return
        subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=str(ROOT));return
    os.execv(sys.executable,[sys.executable,str(ROOT/'server.py')])

if __name__=='__main__':
    try:
        install();relaunch()
    except Exception as e:
        print('\nUPDATE INSTALL FAILED:',e)
        print('Your prospect data/settings were not touched. Press Enter to close.')
        try:input()
        except Exception:pass
        raise
