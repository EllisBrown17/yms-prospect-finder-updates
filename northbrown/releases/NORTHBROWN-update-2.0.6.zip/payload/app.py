#!/usr/bin/env python3
from pathlib import Path
import os, shutil, subprocess, sys, py_compile

ROOT = Path(__file__).resolve().parent
UPDATES = ROOT / 'data' / 'updates'
BACKUPS = UPDATES / 'backups'
PATCH = ROOT / 'upgrade_206.patch'

def fail(msg):
    print('NORTHBROWN_OTA_BOOTSTRAP_ERROR: ' + msg, file=sys.stderr)
    raise SystemExit(1)

if os.getenv('NORTHBROWN_HEALTHCHECK') != '1':
    fail('This bridge only runs inside the verified NORTHBROWN updater health check.')

if not BACKUPS.is_dir():
    fail('Updater backup folder was not found.')
choices = sorted([p for p in BACKUPS.iterdir() if p.is_dir()], key=lambda p: p.stat().st_mtime, reverse=True)
if not choices:
    fail('No updater backup is available.')
backup = choices[0]
old_app = backup / 'app.py'
if not old_app.is_file() or "APP_VERSION = '2.0.5'" not in old_app.read_text(errors='ignore'):
    fail('The newest updater backup is not NORTHBROWN 2.0.5; refusing to patch the wrong version.')
if not PATCH.is_file():
    fail('The 2.0.6 patch is missing.')

# Restore the complete known-good 2.0.5 code from the backup the updater just made.
# User data, .env and the venv are not in this backup and are never touched here.
for item in backup.iterdir():
    dst = ROOT / item.name
    if item.is_dir():
        shutil.copytree(item, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(item, dst)

# Apply the small, deterministic 2.0.5 -> 2.0.6 source delta.
proc = subprocess.run(['/usr/bin/patch','--batch','-p0','-i',str(PATCH)], cwd=str(ROOT), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
if proc.returncode != 0:
    print(proc.stdout, file=sys.stderr)
    fail('The 2.0.6 source patch did not apply cleanly.')

# Verify the finished application before the parent updater commits the install.
checks = {
    'app.py': "APP_VERSION = '2.0.6'",
    'static/app.js': 'watchSmartFinder',
    'static/app.css': 'finder-progress-track',
    'templates/index.html': 'smartFinderProgress',
}
for rel, needle in checks.items():
    p = ROOT / rel
    if not p.is_file() or needle not in p.read_text(errors='ignore'):
        fail('Post-patch verification failed for ' + rel)
for rel in ('app.py','feature_routes.py','builder_routes.py'):
    py_compile.compile(str(ROOT/rel), doraise=True)

try:
    PATCH.unlink()
except OSError:
    pass
print('NORTHBROWN_HEALTHCHECK_OK')
