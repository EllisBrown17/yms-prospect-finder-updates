#!/usr/bin/env python3
# YMS Prospect Finder V4.2.8 — single-prospect + safe scan controls hotfix.
# Fixes missing prospectWorkNotice and adds safe Pause / Resume / Stop controls.

import os, re, sys, time, shutil
from pathlib import Path

TARGET_VERSION = "4.2.8"
APP_DIR = Path(__file__).resolve().parent
if sys.platform == "darwin":
    DATA_DIR = Path.home() / "Library" / "Application Support" / "YMS Prospect Finder V3"
elif os.name == "nt":
    DATA_DIR = Path(os.getenv("APPDATA", Path.home())) / "YMS Prospect Finder V3"
else:
    DATA_DIR = Path.home() / ".yms_prospect_finder_v3"

backup = None

def fail(message):
    global backup
    msg = str(message)
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "update_restart_error.txt").write_text(msg, encoding="utf-8")
    except Exception:
        pass
    try:
        if backup and (backup / "server.py").exists() and (backup / "index.html").exists():
            shutil.copy2(backup / "server.py", APP_DIR / "server.py")
            shutil.copy2(backup / "index.html", APP_DIR / "index.html")
            os.execv(sys.executable, [sys.executable, str(APP_DIR / "server.py")])
    except Exception:
        pass
    raise SystemExit(msg)

BACKEND_INSERT = r'''
# ---------------------------------------------------------------------------
# V4.2.8 safe Smart Pipeline user controls
# ---------------------------------------------------------------------------
import threading as _v428_threading
import time as _v428_time

_v428_controls = {}
_v428_control_lock = _v428_threading.RLock()

def _v428_get_control(job_id):
    with _v428_control_lock:
        return _v428_controls.get(str(job_id or ""), "")

def _v428_set_control(job_id, command):
    jid = str(job_id or "")
    command = str(command or "").strip().lower()
    with _v428_control_lock:
        if command in ("", "resume"):
            _v428_controls.pop(jid, None)
            return ""
        _v428_controls[jid] = command
        return command

def _v428_job_control(job_id, command):
    jid = str(job_id or "")
    command = str(command or "").strip().lower()
    if not jid:
        return {"ok": False, "error": "Missing job id"}
    j = _job_get(jid) or {}
    if not j:
        return {"ok": False, "error": "Job not found", "id": jid}
    action = str(j.get("action") or "")
    title = str(j.get("title") or j.get("detail") or "")
    if action != "pipeline" and "smart pipeline" not in title.lower():
        return {"ok": False, "error": "This control is only available for Smart Pipeline jobs", "id": jid}
    if command == "pause":
        _v428_set_control(jid, "pause")
        _job_set(jid, user_control="pause",
                 detail="Pausing safely — active companies will finish and save, then the scan will wait")
    elif command == "resume":
        _v428_set_control(jid, "")
        _job_set(jid, user_control="", detail="Resuming Smart Pipeline")
    elif command == "stop":
        _v428_set_control(jid, "stop")
        _job_set(jid, user_control="stop", status="stopping",
                 detail="Stopping safely — active companies will finish and save; queued companies will not be scanned")
    else:
        return {"ok": False, "error": "Command must be pause, resume or stop", "id": jid}
    out = dict(_job_get(jid) or {})
    out["ok"] = True
    return out

def _v428_wait_for_control(job_id, company=""):
    jid = str(job_id or "")
    while True:
        cmd = _v428_get_control(jid)
        if cmd == "pause":
            try:
                _job_set(jid, user_control="pause",
                         detail=("Paused safely — completed companies are saved"
                                 + ((" • " + str(company)) if company else "")))
            except Exception:
                pass
            _v428_time.sleep(0.35)
            continue
        return cmd

_v428_previous_process_pipeline_lead = _process_pipeline_lead

def _process_pipeline_lead(id_, job_id="", company_index=0, total=0):
    try:
        lead = get_lead(id_) or {}
        company = lead.get("company") or "Prospect"
    except Exception:
        company = "Prospect"
    cmd = _v428_wait_for_control(job_id, company)
    if cmd == "stop":
        # Leave the prospect untouched so a future scan can pick it up normally.
        return {"status": "stopped", "reason": "Stopped by user", "company": company, "id": id_}
    return _v428_previous_process_pipeline_lead(id_, job_id, company_index, total)

_v428_previous_run_progress_job = _run_progress_job

def _run_progress_job(job_id, action, ids):
    try:
        return _v428_previous_run_progress_job(job_id, action, ids)
    finally:
        if str(action or "") == "pipeline":
            cmd = _v428_get_control(job_id)
            if cmd == "stop":
                try:
                    _job_set(job_id, status="stopped", user_control="stop",
                             detail="Stopped safely — all completed companies were saved; unscanned companies remain available")
                except Exception:
                    pass
            _v428_set_control(job_id, "")
'''

HEAD_FIX = r'''<script id="v428-prospect-open-fix">
/* V4.2.8: required by the prospect drawer. */
function prospectWorkNotice(l){
  l=l||{};
  let msg="";
  if(!l.ai && l.ai_skip_reason) msg=l.ai_skip_reason;
  else if(!((l.web_evidence||{}).text) && l.web_skip_reason) msg=l.web_skip_reason;
  if(!msg) return "";
  const e=(typeof window.esc==="function")?window.esc:function(v){
    return String(v??"").replace(/[&<>"']/g,function(c){return({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]});
  };
  return '<div class="notice warn" style="margin-top:9px"><b>Last attempt:</b> '+e(msg)+'</div>';
}
</script>
'''

BODY_CONTROLS = r'''<script id="v428-pipeline-controls">
(function(){
  const ACTIVE=new Set(["running","queued","stopping"]);
  let current=null, busy=false;

  function isPipeline(j){
    if(!j || typeof j!=="object") return false;
    const a=String(j.action||"").toLowerCase();
    const t=String(j.title||"")+" "+String(j.detail||"");
    return a==="pipeline" || /smart pipeline/i.test(t);
  }
  function jobId(j){ return String((j&&(j.id||j.job_id))||""); }

  function ensureBox(){
    let box=document.getElementById("v428ScanControls");
    if(box) return box;
    box=document.createElement("div");
    box.id="v428ScanControls";
    box.style.cssText=[
      "position:fixed","right:18px","bottom:155px","z-index:99999",
      "min-width:310px","max-width:390px","padding:12px 13px",
      "border:1px solid rgba(255,126,76,.42)","border-radius:14px",
      "background:rgba(8,18,25,.97)","box-shadow:0 16px 38px rgba(0,0,0,.35)",
      "color:#eef6f8","font:12px/1.35 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif"
    ].join(";");
    box.innerHTML=
      '<div style="display:flex;justify-content:space-between;gap:10px;align-items:center">'+
        '<div><b style="font-size:12px">Smart Pipeline controls</b>'+
        '<div id="v428CtlSub" style="opacity:.72;margin-top:2px">Completed companies are saved automatically.</div></div>'+
        '<div style="display:flex;gap:7px">'+
          '<button id="v428PauseBtn" type="button" style="cursor:pointer;border:1px solid #49616a;background:#172a32;color:#fff;border-radius:9px;padding:7px 10px;font-weight:700">Pause</button>'+
          '<button id="v428StopBtn" type="button" style="cursor:pointer;border:0;background:#ff7448;color:#fff;border-radius:9px;padding:7px 10px;font-weight:800">Stop</button>'+
        '</div>'+
      '</div>';
    document.body.appendChild(box);

    box.querySelector("#v428PauseBtn").addEventListener("click",async function(){
      if(busy||!current) return;
      const paused=String(current.user_control||"")==="pause";
      await sendControl(paused?"resume":"pause");
    });
    box.querySelector("#v428StopBtn").addEventListener("click",async function(){
      if(busy||!current) return;
      if(!confirm("Stop Smart Pipeline safely?\n\nCompanies that have already finished will stay saved. Any companies currently being processed will be allowed to finish/checkpoint, then the remaining queue will stop.")) return;
      await sendControl("stop");
    });
    return box;
  }

  function paint(){
    const box=ensureBox();
    if(!current || !isPipeline(current) || !(ACTIVE.has(String(current.status||"")) || String(current.user_control||"")==="pause")){
      box.style.display="none"; return;
    }
    box.style.display="block";
    const paused=String(current.user_control||"")==="pause";
    const stopping=String(current.user_control||"")==="stop" || String(current.status||"")==="stopping";
    const p=box.querySelector("#v428PauseBtn"), s=box.querySelector("#v428StopBtn"), sub=box.querySelector("#v428CtlSub");
    p.textContent=paused?"Resume":"Pause";
    p.disabled=busy||stopping;
    s.disabled=busy||stopping;
    p.style.opacity=p.disabled?".55":"1";
    s.style.opacity=s.disabled?".55":"1";
    sub.textContent=stopping
      ?"Stopping safely — finished companies are being kept."
      :(paused
        ?"Paused safely. Finished companies are saved; click Resume to continue."
        :"Completed companies are saved automatically. Pause or stop without losing them.");
  }

  async function sendControl(command){
    const id=jobId(current);
    if(!id) return;
    busy=true; paint();
    try{
      const r=await fetch("/api/job/control",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({id:id,command:command})
      });
      const j=await r.json();
      if(!r.ok || j.ok===false) throw new Error(j.error||("HTTP "+r.status));
      current=j;
    }catch(e){
      alert("Could not "+command+" Smart Pipeline: "+e.message);
    }finally{
      busy=false; paint();
    }
  }

  async function poll(){
    try{
      const r=await fetch("/api/job/recent",{cache:"no-store"});
      if(r.ok){
        const j=await r.json();
        if(isPipeline(j)) current=j;
        else if(current && !ACTIVE.has(String(current.status||""))) current=null;
        paint();
      }
    }catch(e){}
  }

  function installPaintHook(){
    if(typeof window.paintJob==="function" && !window.paintJob.__v428wrapped){
      const old=window.paintJob;
      const wrapped=function(j){
        const out=old.apply(this,arguments);
        try{ if(isPipeline(j)){current=j;paint();} }catch(e){}
        return out;
      };
      wrapped.__v428wrapped=true;
      window.paintJob=wrapped;
      return true;
    }
    return false;
  }

  installPaintHook();
  let tries=0;
  const hookTimer=setInterval(function(){if(installPaintHook()||++tries>30)clearInterval(hookTimer)},250);
  setInterval(poll,1200);
  setTimeout(poll,100);
})();
</script>
'''

def patch_backend(source):
    source, n = re.subn(r'APP_VERSION\s*=\s*["\'][^"\']+["\']',
                        'APP_VERSION = "4.2.8"', source, count=1)
    if n != 1:
        raise RuntimeError("Could not update APP_VERSION")

    if "# V4.2.8 safe Smart Pipeline user controls" not in source:
        marker = "class Handler(SimpleHTTPRequestHandler):"
        if marker not in source:
            raise RuntimeError("Could not locate HTTP Handler for V4.2.8 backend controls")
        if "def _process_pipeline_lead(" not in source or "def _run_progress_job(" not in source:
            raise RuntimeError("Current app does not contain the Smart Pipeline worker hooks expected by V4.2.8")
        source = source.replace(marker, BACKEND_INSERT + "\n\n" + marker, 1)

    if 'if p=="/api/job/control":' not in source:
        marker = '            if p=="/api/job/start":\n'
        if marker not in source:
            raise RuntimeError("Could not locate /api/job/start route")
        route = (
            '            if p=="/api/job/control":\n'
            '                self.sendj(_v428_job_control(b.get("id") or b.get("job_id"),b.get("command")));return\n'
        )
        source = source.replace(marker, route + marker, 1)

    return source

def patch_frontend(html):
    if 'id="v428-prospect-open-fix"' not in html:
        if "</head>" not in html:
            raise RuntimeError("Could not locate </head> for prospect-open fix")
        html = html.replace("</head>", HEAD_FIX + "\n</head>", 1)

    if 'id="v428-pipeline-controls"' not in html:
        if "</body>" not in html:
            raise RuntimeError("Could not locate </body> for Smart Pipeline controls")
        html = html.replace("</body>", BODY_CONTROLS + "\n</body>", 1)

    html = html.replace('["complete","failed","paused"]', '["complete","failed","paused","stopped"]')
    html = html.replace("['complete','failed','paused']", "['complete','failed','paused','stopped']")

    platform = "Mac" if sys.platform == "darwin" else ("Windows" if os.name == "nt" else "Desktop")
    html = re.sub(r'<title>YMS Prospect Finder V[^<]+ — YMS-Tools</title>',
                  f'<title>YMS Prospect Finder V4.2.8 {platform} — YMS-Tools</title>', html, count=1)
    html = re.sub(r'<b id="versionLabel">Prospect Finder V[^<]+</b>',
                  f'<b id="versionLabel">Prospect Finder V4.2.8 {platform}</b>', html, count=1)
    return html

try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    backups = DATA_DIR / "update-backups"
    choices = []
    if backups.exists():
        for p in backups.glob("before-" + TARGET_VERSION + "-*"):
            if (p / "server.py").exists() and (p / "index.html").exists():
                try:
                    choices.append((p.stat().st_mtime, p))
                except Exception:
                    pass
    if not choices:
        fail("V4.2.8 could not find the updater-created safe pre-update backup. Nothing was changed.")
    backup = max(choices, key=lambda x: x[0])[1]

    server_source = (backup / "server.py").read_text("utf-8")
    html_source = (backup / "index.html").read_text("utf-8")

    server_new = patch_backend(server_source)
    html_new = patch_frontend(html_source)

    compile(server_new, "v4.2.8-server.py", "exec")
    if 'function prospectWorkNotice(l)' not in html_new:
        raise RuntimeError("Prospect drawer helper validation failed")
    if "/api/job/control" not in server_new or "_v428_wait_for_control" not in server_new:
        raise RuntimeError("Smart Pipeline controls validation failed")
    if 'v428ScanControls' not in html_new:
        raise RuntimeError("Smart Pipeline control UI validation failed")

    temp_server = APP_DIR / "server.py.v428.tmp"
    temp_html = APP_DIR / "index.html.v428.tmp"
    temp_server.write_text(server_new, encoding="utf-8")
    temp_html.write_text(html_new, encoding="utf-8")

    os.replace(temp_server, APP_DIR / "server.py")
    os.replace(temp_html, APP_DIR / "index.html")

    try:
        (DATA_DIR / "last_ota_update.txt").write_text(
            "4.2.8\n" + time.strftime("%Y-%m-%d %H:%M:%S") +
            "\nSingle-prospect drawer fix + safe Smart Pipeline pause/resume/stop controls\n",
            encoding="utf-8",
        )
    except Exception:
        pass

except Exception as exc:
    fail(exc)

os.execv(sys.executable, [sys.executable, str(APP_DIR / "server.py")])
