#!/usr/bin/env python3
"""YMS Prospect Finder V4.2.11 — persistent Desktop launcher + icon repair."""
import os,re,sys,time,shutil,subprocess
from pathlib import Path
TARGET_VERSION="4.2.11"
APP_DIR=Path(__file__).resolve().parent
if sys.platform=="darwin":DATA_DIR=Path.home()/"Library"/"Application Support"/"YMS Prospect Finder V3"
elif os.name=="nt":DATA_DIR=Path(os.getenv("APPDATA",Path.home()))/"YMS Prospect Finder V3"
else:DATA_DIR=Path.home()/".yms_prospect_finder_v3"
backup=None
LAUNCHER_REFRESH_SCRIPT='#!/usr/bin/env python3\nimport os, re, sys, time, shutil, subprocess\nfrom pathlib import Path\n\nSHELL_SCRIPT = \'#!/bin/bash\\nset -u\\nDATA="$HOME/Library/Application Support/YMS Prospect Finder V3"\\nLOG="$HOME/Library/Logs/YMS Prospect Finder.log"\\nPTR="$DATA/runtime_path.txt"\\nPYPTR="$DATA/runtime_python.txt"\\nPORT=8765\\nURL="http://127.0.0.1:$PORT"\\nmkdir -p "$HOME/Library/Logs"\\nSERVER=""\\nPY=""\\n\\nif [ -f "$PTR" ]; then\\n  RUNTIME="$(cat "$PTR" 2>/dev/null || true)"\\n  if [ -n "$RUNTIME" ] && [ -f "$RUNTIME/server.py" ]; then SERVER="$RUNTIME/server.py"; fi\\nfi\\nif [ -f "$PYPTR" ]; then\\n  CANDPY="$(cat "$PYPTR" 2>/dev/null || true)"\\n  if [ -n "$CANDPY" ] && [ -x "$CANDPY" ]; then PY="$CANDPY"; fi\\nfi\\nif [ -z "$PY" ]; then\\n  for CANDPY in "/opt/homebrew/bin/python3" "/usr/local/bin/python3" "/usr/bin/python3"; do\\n    if [ -x "$CANDPY" ]; then PY="$CANDPY"; break; fi\\n  done\\nfi\\nif [ -z "$SERVER" ]; then\\n  for CAND in \\\\\\n    "$HOME/Downloads/YMS_Prospect_Finder_V4_1_0_OTA_UPDATER_MAC/server.py" \\\\\\n    "$HOME/Applications/YMS Prospect Finder/server.py"; do\\n    if [ -f "$CAND" ]; then SERVER="$CAND"; break; fi\\n  done\\nfi\\nif [ -z "$SERVER" ] || [ -z "$PY" ]; then\\n  /usr/bin/osascript -e \\\'display alert "YMS Prospect Finder" message "The YMS runtime or Python interpreter could not be found. Open the current YMS server from Terminal once, then install the latest update." as critical\\\'\\n  exit 1\\nfi\\n\\nif /usr/bin/curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then\\n  /usr/bin/open "$URL"\\n  exit 0\\nfi\\n\\n/usr/bin/nohup "$PY" "$SERVER" >> "$LOG" 2>&1 &\\n\\nfor i in {1..60}; do\\n  if /usr/bin/curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then\\n    /usr/bin/open "$URL"\\n    exit 0\\n  fi\\n  /bin/sleep 0.5\\ndone\\n\\n/usr/bin/osascript -e \\\'display alert "YMS Prospect Finder" message "YMS did not start successfully, so Safari was not opened to a dead page. Check ~/Library/Logs/YMS Prospect Finder.log or launch the server from Terminal." as critical\\\'\\nexit 1\\n\'\n\ndef main():\n    if sys.platform != "darwin":\n        return 0\n    if len(sys.argv) < 3:\n        return 2\n    app_dir = Path(sys.argv[1]).expanduser().resolve()\n    data_dir = Path(sys.argv[2]).expanduser().resolve()\n    python_exe = str(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] else sys.executable\n    data_dir.mkdir(parents=True, exist_ok=True)\n    (data_dir / "runtime_path.txt").write_text(str(app_dir), encoding="utf-8")\n    (data_dir / "runtime_python.txt").write_text(str(python_exe), encoding="utf-8")\n\n    stable_icon = data_dir / "YMSProspectFinder.icns"\n    app_icon = app_dir / "assets" / "YMSProspectFinder.icns"\n    if app_icon.exists():\n        try: shutil.copy2(app_icon, stable_icon)\n        except Exception: pass\n\n    version = "4.2.11"\n    try:\n        runtime_text = (app_dir / "server.py").read_text("utf-8", errors="ignore")\n        m = re.search(r\'APP_VERSION\\s*=\\s*["\\\']([^"\\\']+)["\\\']\', runtime_text)\n        if m: version = m.group(1)\n    except Exception: pass\n    bundle_version = "".join(re.findall(r"\\d+", version)) or "4211"\n\n    desktop = Path.home() / "Desktop"\n    desktop.mkdir(parents=True, exist_ok=True)\n    target = desktop / "YMS Prospect Finder.app"\n    build_root = data_dir / "launcher-build"\n    build = build_root / "YMS Prospect Finder.app"\n    shutil.rmtree(build_root, ignore_errors=True)\n    macos = build / "Contents" / "MacOS"\n    resources = build / "Contents" / "Resources"\n    macos.mkdir(parents=True, exist_ok=True)\n    resources.mkdir(parents=True, exist_ok=True)\n\n    icon_source = stable_icon if stable_icon.exists() else app_icon\n    if icon_source.exists(): shutil.copy2(icon_source, resources / "YMSProspectFinder.icns")\n\n    exe = macos / "YMS Prospect Finder"\n    exe.write_text(SHELL_SCRIPT, encoding="utf-8")\n    os.chmod(exe, 0o755)\n\n    plist = f"""<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n<key>CFBundleDisplayName</key><string>YMS Prospect Finder</string>\n<key>CFBundleExecutable</key><string>YMS Prospect Finder</string>\n<key>CFBundleIdentifier</key><string>uk.co.ymstools.prospectfinder.launcher</string>\n<key>CFBundleName</key><string>YMS Prospect Finder</string>\n<key>CFBundlePackageType</key><string>APPL</string>\n<key>CFBundleShortVersionString</key><string>{version}</string>\n<key>CFBundleVersion</key><string>{bundle_version}</string>\n<key>CFBundleIconFile</key><string>YMSProspectFinder.icns</string>\n<key>LSUIElement</key><true/>\n<key>NSHighResolutionCapable</key><true/>\n</dict></plist>"""\n    (build / "Contents" / "Info.plist").write_text(plist, encoding="utf-8")\n\n    if target.exists() or target.is_symlink():\n        if target.is_dir() and not target.is_symlink(): shutil.rmtree(target, ignore_errors=False)\n        else: target.unlink()\n    shutil.copytree(build, target)\n    for cmd, timeout in [\n        (["/usr/bin/xattr","-dr","com.apple.quarantine",str(target)],10),\n        (["/usr/bin/codesign","--force","--deep","--sign","-",str(target)],20),\n        (["/usr/bin/touch",str(target)],5),\n    ]:\n        try: subprocess.run(cmd, timeout=timeout, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n        except Exception: pass\n    (data_dir / "launcher_refresh_status.txt").write_text(\n        version + "\\n" + time.strftime("%Y-%m-%d %H:%M:%S") + "\\n" + str(target) + "\\n" + python_exe + "\\n",\n        encoding="utf-8")\n    return 0\n\nif __name__ == "__main__":\n    try: raise SystemExit(main())\n    except Exception as exc:\n        try:\n            data = Path(sys.argv[2]) if len(sys.argv) > 2 else Path.home()/"Library"/"Application Support"/"YMS Prospect Finder V3"\n            data.mkdir(parents=True, exist_ok=True)\n            (data / "launcher_refresh_error.txt").write_text(str(exc), encoding="utf-8")\n        except Exception: pass\n        raise\n'
RUNTIME_HOOK='\n# ---------------------------------------------------------------------------\n# V4.2.11 persistent Desktop launcher + icon self-heal\n# ---------------------------------------------------------------------------\n_v4211_original_write_update_helper = _write_update_helper\n\ndef _v4211_refresh_desktop_launcher():\n    try:\n        DATA_DIR.mkdir(parents=True, exist_ok=True)\n        (DATA_DIR / "runtime_path.txt").write_text(str(APP_DIR), encoding="utf-8")\n        (DATA_DIR / "runtime_python.txt").write_text(str(sys.executable), encoding="utf-8")\n        helper = DATA_DIR / "launcher_refresh.py"\n        if sys.platform == "darwin" and helper.exists():\n            subprocess.run([sys.executable, str(helper), str(APP_DIR), str(DATA_DIR), str(sys.executable)],\n                           timeout=25, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n    except Exception as ex:\n        try:(DATA_DIR / "launcher_refresh_error.txt").write_text(str(ex), encoding="utf-8")\n        except Exception:pass\n\ndef _write_update_helper(staged_zip, expected_version):\n    helper = _v4211_original_write_update_helper(staged_zip, expected_version)\n    text = helper.read_text("utf-8")\n    marker = \'try:\\n    if os.name=="nt" and (app_dir/"Start YMS Prospect Finder.bat").exists():\'\n    inject = \'# V4.2.11 persistent Desktop launcher refresh on every OTA\\ntry:\\n    refresh=data_dir/"launcher_refresh.py"\\n    if refresh.exists():\\n        subprocess.run([py,str(refresh),str(app_dir),str(data_dir),py],timeout=30,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\\nexcept Exception as e:\\n    try:(data_dir/"launcher_refresh_error.txt").write_text(str(e),encoding="utf-8")\\n    except Exception:pass\\n\'\n    if "V4.2.11 persistent Desktop launcher refresh on every OTA" not in text:\n        if marker not in text:\n            raise RuntimeError("Could not attach the persistent Desktop refresh to the OTA helper")\n        text = text.replace(marker, inject + marker, 1)\n        helper.write_text(text, encoding="utf-8")\n    return helper\n\n_v4211_refresh_desktop_launcher()\n'

def fail(message):
    global backup
    msg=str(message)
    try:
        DATA_DIR.mkdir(parents=True,exist_ok=True)
        (DATA_DIR/"update_restart_error.txt").write_text(msg,encoding="utf-8")
    except Exception:pass
    try:
        if backup and (backup/"server.py").exists() and (backup/"index.html").exists():
            shutil.copy2(backup/"server.py",APP_DIR/"server.py");shutil.copy2(backup/"index.html",APP_DIR/"index.html")
            os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
    except Exception:pass
    raise SystemExit(msg)

def latest_preupdate_backup():
    backups=DATA_DIR/"update-backups";choices=[]
    if backups.exists():
        for p in backups.glob("before-"+TARGET_VERSION+"-*"):
            if (p/"server.py").exists() and (p/"index.html").exists():
                try:choices.append((p.stat().st_mtime,p))
                except Exception:pass
    if not choices:fail("V4.2.11 could not find the updater-created safe pre-update backup. Nothing was changed.")
    return max(choices,key=lambda x:x[0])[1]

def patch_runtime(s,h):
    s,n=re.subn(r'APP_VERSION\s*=\s*["\'][^"\']+["\']',f'APP_VERSION = "{TARGET_VERSION}"',s,count=1)
    if n!=1:raise RuntimeError("Could not update APP_VERSION")
    if "# V4.2.11 persistent Desktop launcher + icon self-heal" not in s:
        marker="class Handler(SimpleHTTPRequestHandler):"
        if marker not in s:raise RuntimeError("Could not locate HTTP Handler for persistent launcher hook")
        s=s.replace(marker,RUNTIME_HOOK+"\n\n"+marker,1)
    platform="Mac" if sys.platform=="darwin" else ("Windows" if os.name=="nt" else "Desktop")
    h=re.sub(r'<title>YMS Prospect Finder V[^<]+ — YMS-Tools</title>',f'<title>YMS Prospect Finder V{TARGET_VERSION} {platform} — YMS-Tools</title>',h,count=1)
    h=re.sub(r'<b id="versionLabel">Prospect Finder V[^<]+</b>',f'<b id="versionLabel">Prospect Finder V{TARGET_VERSION} {platform}</b>',h,count=1)
    h=re.sub(r'id="updateSettingsBadge">V[^<]+<',f'id="updateSettingsBadge">V{TARGET_VERSION}<',h,count=1)
    return s,h

try:
    backup=latest_preupdate_backup()
    s=(backup/"server.py").read_text("utf-8");h=(backup/"index.html").read_text("utf-8")
    if "def _write_update_helper(" not in s or "class Handler(SimpleHTTPRequestHandler):" not in s:
        raise RuntimeError("Current runtime is missing the expected OTA launcher hooks")
    s,h=patch_runtime(s,h)
    compile(s,"v4.2.11-runtime-server.py","exec")
    if "_v4211_original_write_update_helper" not in s or "runtime_python.txt" not in s:
        raise RuntimeError("Persistent launcher hook validation failed")
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    helper=DATA_DIR/"launcher_refresh.py";helper.write_text(LAUNCHER_REFRESH_SCRIPT,encoding="utf-8")
    try:os.chmod(helper,0o755)
    except Exception:pass
    app_icon=APP_DIR/"assets"/"YMSProspectFinder.icns"
    if app_icon.exists():shutil.copy2(app_icon,DATA_DIR/"YMSProspectFinder.icns")
    (APP_DIR/"server.py").write_text(s,encoding="utf-8");(APP_DIR/"index.html").write_text(h,encoding="utf-8")
    (DATA_DIR/"runtime_path.txt").write_text(str(APP_DIR),encoding="utf-8")
    (DATA_DIR/"runtime_python.txt").write_text(str(sys.executable),encoding="utf-8")
    if sys.platform=="darwin":
        subprocess.run([sys.executable,str(helper),str(APP_DIR),str(DATA_DIR),str(sys.executable)],timeout=30,
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    (DATA_DIR/"last_ota_update.txt").write_text(TARGET_VERSION+"\n"+time.strftime('%Y-%m-%d %H:%M:%S')+"\nPersistent Desktop launcher/icon self-heal installed\n",encoding="utf-8")
except Exception as exc:fail(exc)
os.execv(sys.executable,[sys.executable,str(APP_DIR/"server.py")])
