#!/bin/bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

FULL_SHA="88f45969ed801323252b83529929dd66848560347105816cb15db727e3e69f0e"
RAW_BASE="https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.0"
CACHE="$ROOT/data/updates/northbrown-2.0-bootstrap"
mkdir -p "$CACHE"

PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY="$(command -v python3 || true)"

install_builder_2() {
  local stage="$CACHE/stage"
  local b64="$CACHE/northbrown-2.0.b64"
  local zip="$CACHE/NORTHBROWN-update-2.0.0.zip"
  rm -rf "$stage" "$b64" "$zip"
  mkdir -p "$stage"

  echo "NORTHBROWN 2.0: downloading the Website Builder…"
  for n in 00 01 02 03 04 05 06 07; do
    /usr/bin/curl -fsSL --retry 3 --connect-timeout 10 \
      "$RAW_BASE/ota.part$n" >> "$b64" || return 1
  done
  /usr/bin/base64 -D -i "$b64" -o "$zip" || return 1
  local actual
  actual="$(/usr/bin/shasum -a 256 "$zip" | /usr/bin/awk '{print $1}')"
  [ "$actual" = "$FULL_SHA" ] || { echo "NORTHBROWN 2.0 checksum failed; keeping the current app." >&2; return 1; }
  /usr/bin/unzip -t "$zip" >/dev/null || return 1
  /usr/bin/unzip -q "$zip" -d "$stage" || return 1
  [ -f "$stage/payload/bootstrap.py" ] || return 1
  [ -f "$stage/payload/builder_routes.py" ] || return 1
  [ -f "$stage/payload/static/app.js" ] || return 1
  [ -f "$stage/payload/templates/index.html" ] || return 1
  [ -n "$PY" ] || return 1
  "$PY" -m py_compile "$stage/payload/bootstrap.py" "$stage/payload/builder_routes.py" || return 1
  /usr/bin/grep -q "Created by Ellis Brown / NORTHBROWN" "$stage/payload/builder_routes.py" || return 1
  /usr/bin/grep -q "NORTHBROWN WEBSITE BUILDER" "$stage/payload/templates/index.html" || return 1

  /usr/bin/rsync -a \
    --exclude='.env' --exclude='.venv/' --exclude='data/' --exclude='northbrown.log' \
    "$stage/payload/" "$ROOT/" || return 1
  chmod +x "$ROOT/START_NORTHBROWN_INTERNAL.sh" 2>/dev/null || true
  xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
  touch "$ROOT/.builder_2_ready"
  rm -rf "$stage" "$b64"
  echo "NORTHBROWN 2.0 Website Builder installed. Restarting…"
  exec bash "$ROOT/START_NORTHBROWN_INTERNAL.sh"
}

if [ ! -f "$ROOT/.builder_2_ready" ] || [ ! -f "$ROOT/bootstrap.py" ] || [ ! -f "$ROOT/builder_routes.py" ]; then
  if ! install_builder_2; then
    echo "Website Builder download could not be completed. NORTHBROWN 1.5.1 will open normally; no data was lost." >&2
  fi
fi

# Safe fallback if the bootstrap download was unavailable.
if [ -n "$PY" ] && [ -f "$ROOT/bootstrap.py" ] && [ -f "$ROOT/builder_routes.py" ]; then
  exec "$PY" "$ROOT/bootstrap.py"
fi
if [ -n "$PY" ]; then
  exec "$PY" "$ROOT/app.py"
fi
echo "Python was not found. Open the recovery installer to repair NORTHBROWN." >&2
exit 1
