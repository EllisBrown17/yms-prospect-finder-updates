# NORTHBROWN 2.0.11 verified migration bridge.
# Downloads the already-published, SHA-256-verified staged payload BEFORE changing live code.
from pathlib import Path
import base64, hashlib, json, os, re, shutil, subprocess, sys, tempfile, urllib.request, zipfile

ROOT=Path(__file__).resolve().parent
UPDATES=ROOT/'data'/'updates'
BASE='2.0.8'; TARGET='2.0.11'
CORE=('app.py','feature_routes.py','builder_routes.py','requirements.txt','templates/index.html','static/app.js','static/app.css')
PARTS=[f'part{i}.b64' for i in range(6)]
RAW='https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/nb211-build/northbrown/build/2.0.11/'
FULL_SIZE=30344
FULL_SHA='9f21b5b4ae64a0ce29ba8326b6762495a2a236c28f9a76efabf83238cc609f41'

def backup():
    b=UPDATES/'backups'; found=[]
    if b.exists():
        for p in b.iterdir():
            try:
                if p.is_dir() and (p/'VERSION.txt').read_text().strip()==BASE and all((p/r).is_file() and (p/r).stat().st_size>20 for r in CORE): found.append(p)
            except Exception: pass
    if not found: raise RuntimeError('No valid updater-created NORTHBROWN 2.0.8 backup was found.')
    return max(found,key=lambda p:p.stat().st_mtime)

def restore_and_relaunch(b):
    try:
        for r in CORE+('VERSION.txt',):
            s=b/r; d=ROOT/r
            if s.exists(): d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s,d)
        launcher=Path.home()/'Applications'/'NORTHBROWN Lead Engine.app'
        cmd=f'sleep 2; open {json.dumps(str(launcher))}' if launcher.exists() else f'sleep 2; bash {json.dumps(str(ROOT/"START_NORTHBROWN_INTERNAL.sh"))}'
        subprocess.Popen(['bash','-lc',cmd],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
    except Exception: pass

def get_payload(tmp):
    local=os.getenv('NORTHBROWN_211_PARTS_DIR','').strip(); chunks=[]
    for name in PARTS:
        if local: data=(Path(local)/name).read_bytes()
        else:
            req=urllib.request.Request(RAW+name,headers={'User-Agent':'NORTHBROWN-2.0.11'})
            with urllib.request.urlopen(req,timeout=10) as r: data=r.read()
        chunks.append(data.strip())
    raw=base64.b64decode(b''.join(chunks),validate=True)
    if len(raw)!=FULL_SIZE or hashlib.sha256(raw).hexdigest()!=FULL_SHA: raise RuntimeError('2.0.11 staged payload verification failed.')
    z=tmp/'full.zip'; z.write_bytes(raw)
    with zipfile.ZipFile(z) as zf:
        bad=zf.testzip()
        if bad: raise RuntimeError('2.0.11 staged ZIP integrity check failed.')
        for n in ('payload/design_dna_engine.py','payload/smart_scan_engine.py','payload/ui_patch.js','payload/ui_patch.css'):
            if n not in zf.namelist(): raise RuntimeError('2.0.11 staged payload is incomplete.')
            (tmp/Path(n).name).write_bytes(zf.read(n))

def patch_app(t):
    t,n=re.subn(r"APP_VERSION\s*=\s*(['\"])2\.0\.8\1","APP_VERSION = '2.0.11'",t,count=1)
    if n!=1 and "APP_VERSION = '2.0.11'" not in t: raise RuntimeError('Could not safely update version marker.')
    if 'install_design_dna(app, globals())' not in t:
        needle='register_builder_routes(app, globals())\n'
        if needle not in t: raise RuntimeError('Could not locate builder registration point.')
        block=needle+"\n# NORTHBROWN 2.0.11 engines\nfrom design_dna_engine import install_design_dna\nfrom smart_scan_engine import install_smart_scan\ninstall_design_dna(app, globals())\ninstall_smart_scan(app, globals())\n"
        t=t.replace(needle,block,1)
    return t

def append(dst,src,marker):
    t=dst.read_text(encoding='utf-8')
    if marker not in t: dst.write_text(t.rstrip()+'\n\n'+src.read_text(encoding='utf-8').rstrip()+'\n',encoding='utf-8')

def main():
    b=backup(); tmp=Path(tempfile.mkdtemp(prefix='nb211-',dir=str(UPDATES)))
    try:
        # Preflight network + payload checks before touching working application files.
        get_payload(tmp)
        work=tmp/'work'
        for r in CORE:
            s=b/r; d=work/r; d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s,d)
        (work/'app.py').write_text(patch_app((work/'app.py').read_text(encoding='utf-8')),encoding='utf-8')
        append(work/'static/app.js',tmp/'ui_patch.js','NORTHBROWN 2.0.11 — all-business Smart Finder')
        append(work/'static/app.css',tmp/'ui_patch.css','NORTHBROWN 2.0.11 Smart Finder / Overnight Scan')
        (work/'VERSION.txt').write_text(TARGET+'\n')
        for n in ('design_dna_engine.py','smart_scan_engine.py'): shutil.copy2(tmp/n,work/n)
        subprocess.run([sys.executable,'-m','py_compile',str(work/'app.py'),str(work/'feature_routes.py'),str(work/'builder_routes.py'),str(work/'design_dna_engine.py'),str(work/'smart_scan_engine.py')],check=True,capture_output=True,text=True)
        for r in CORE+('VERSION.txt','design_dna_engine.py','smart_scan_engine.py'):
            s=work/r; d=ROOT/r; d.parent.mkdir(parents=True,exist_ok=True); x=d.with_suffix(d.suffix+'.new'); shutil.copy2(s,x); os.replace(x,d)
        (UPDATES/'northbrown-2.0.11.done').write_text(json.dumps({'version':TARGET,'verified_payload_sha256':FULL_SHA}))
    except Exception:
        restore_and_relaunch(b); raise
    finally: shutil.rmtree(tmp,ignore_errors=True)
    if os.getenv('NORTHBROWN_TRANSITION_TEST')=='1': print('NORTHBROWN_2_0_11_TRANSITION_OK'); return
    os.execv(sys.executable,[sys.executable,str(ROOT/'app.py')])

if __name__=='__main__': main()
