"""NORTHBROWN 2.0.1 safe Website Builder bootstrap.

This is intentionally small. The existing NORTHBROWN core is preserved from the
OTA backup and the verified Website Builder runtime is reconstructed from the
GitHub staging bundle. If any verification step fails, the normal OTA rollback
keeps the previous working install.
"""
from __future__ import annotations

import base64
import glob
import hashlib
import importlib.util
import io
import os
import py_compile
import shutil
import socket
import sys
import urllib.request
import zipfile
from pathlib import Path

APP_VERSION = '2.0.1'
ROOT = Path(__file__).resolve().parent
CORE_PATH = ROOT / '_northbrown_core.py'
STAGE_SHA256 = '88f45969ed801323252b83529929dd66848560347105816cb15db727e3e69f0e'
STAGE_BASE = 'https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.0'
STAGE_PARTS = [f'ota.part{i:02d}' for i in range(8)]
RUNTIME_FILES = {
    'payload/builder_routes.py': ROOT / 'builder_routes.py',
    'payload/static/app.js': ROOT / 'static' / 'app.js',
    'payload/static/app.css': ROOT / 'static' / 'app.css',
    'payload/templates/index.html': ROOT / 'templates' / 'index.html',
}


def _preserve_core() -> Path:
    if CORE_PATH.is_file():
        return CORE_PATH
    backups = sorted(
        glob.glob(str(ROOT / 'data' / 'updates' / 'backups' / '*' / 'app.py')),
        reverse=True,
    )
    for candidate in backups:
        try:
            text = Path(candidate).read_text(encoding='utf-8', errors='ignore')[:12000]
            if 'NORTHBROWN 2.0.1 safe Website Builder bootstrap' in text:
                continue
            shutil.copy2(candidate, CORE_PATH)
            return CORE_PATH
        except OSError:
            continue
    raise RuntimeError('Could not recover the previous NORTHBROWN core from the OTA backup.')


def _download_stage_zip() -> bytes:
    local = os.getenv('NORTHBROWN_RUNTIME_STAGE_ZIP', '').strip()
    if local:
        data = Path(local).read_bytes()
    else:
        pieces: list[str] = []
        for name in STAGE_PARTS:
            url = f'{STAGE_BASE}/{name}'
            req = urllib.request.Request(url, headers={'User-Agent': 'NORTHBROWN-Lead-Engine/2.0.1'})
            with urllib.request.urlopen(req, timeout=25) as response:
                raw = response.read(15000)
            pieces.append(raw.decode('ascii').strip())
        data = base64.b64decode(''.join(pieces), validate=True)
    if hashlib.sha256(data).hexdigest() != STAGE_SHA256:
        raise RuntimeError('Website Builder runtime failed SHA-256 verification.')
    return data


def _install_builder_runtime() -> None:
    data = _download_stage_zip()
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = set(zf.namelist())
        for member, destination in RUNTIME_FILES.items():
            if member not in names:
                raise RuntimeError(f'Website Builder runtime is missing {member}.')
            destination.parent.mkdir(parents=True, exist_ok=True)
            tmp = destination.with_suffix(destination.suffix + '.new')
            tmp.write_bytes(zf.read(member))
            os.replace(tmp, destination)
    py_compile.compile(str(ROOT / 'builder_routes.py'), doraise=True)


def _prepare() -> Path:
    core = _preserve_core()
    py_compile.compile(str(core), doraise=True)
    _install_builder_runtime()
    return core


if os.getenv('NORTHBROWN_HEALTHCHECK') == '1':
    _prepare()
    print('NORTHBROWN_HEALTHCHECK_OK')
    raise SystemExit(0)

_core_file = _prepare()
_spec = importlib.util.spec_from_file_location('_northbrown_core_runtime', _core_file)
if _spec is None or _spec.loader is None:
    raise RuntimeError('Could not load the preserved NORTHBROWN core.')
_core = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _core
_spec.loader.exec_module(_core)
_core.APP_VERSION = APP_VERSION

from builder_routes import register_builder_routes
register_builder_routes(_core.app, vars(_core))

# Re-export legacy names for compatibility with existing helper modules/routes.
for _name, _value in vars(_core).items():
    if not _name.startswith('__') and _name not in globals():
        globals()[_name] = _value
APP_VERSION = '2.0.1'

if __name__ == '__main__':
    port = int(os.getenv('PORT', '5055'))
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(('8.8.8.8', 80))
        lan_ip = sock.getsockname()[0]
        sock.close()
    except Exception:
        lan_ip = 'YOUR-MAC-IP'
    print(f'\nNORTHBROWN Lead Engine 2.0.1 — Website Builder\n  Mac: http://127.0.0.1:{port}\n  iPhone: http://{lan_ip}:{port}  (same Wi-Fi)\n')
    _core.app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
