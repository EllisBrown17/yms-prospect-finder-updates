# NORTHBROWN 2.0.10 recovery + Design DNA OTA bridge.
# Handles installs from 2.0.7, 2.0.8 or 2.0.9 and rebuilds the live app
# from the updater-created backup before the outer updater health-check commits.
from pathlib import Path
import base64, gzip, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
UPDATES = ROOT / 'data' / 'updates'
TARGET = '2.0.10'
SUPPORTED_BASES = ('2.0.9', '2.0.8', '2.0.7')
MARKER = UPDATES / 'northbrown-2.0.10-recovery-design-dna.done'
STAGING = 'https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.9/'
PARTS = ['dna00.b64','dna01.b64','dna02.b64','dna03.b64']
GZ_SHA = 'c05fda2f902fb29406b704db993b4c609538cba3e55e1c7736ed3b5879081cdc'
OVERLAY_SHA = '6b03096253dbf8f0f4a5b821a4b164924208463afebfd7c8f9503a79408e69cc'
CORE = (
    'app.py', 'feature_routes.py', 'builder_routes.py', 'requirements.txt',
    'templates/index.html', 'static/app.js', 'static/app.css'
)


def _backup_version(path):
    try:
        return (path / 'VERSION.txt').read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def find_backup():
    """Pick the newest updater-created backup that can be migrated safely."""
    root = UPDATES / 'backups'
    candidates = []
    if root.exists():
        for p in root.iterdir():
            if not p.is_dir():
                continue
            version = _backup_version(p)
            if version not in SUPPORTED_BASES:
                continue
            try:
                if (p / 'app.py').stat().st_size > 50000 and (p / 'builder_routes.py').stat().st_size > 50000:
                    candidates.append((p.stat().st_mtime, p, version))
            except Exception:
                pass
    if not candidates:
        raise RuntimeError(
            'NORTHBROWN 2.0.10 could not find a recent 2.0.7, 2.0.8 or 2.0.9 updater backup. '
            'Nothing was changed.'
        )
    candidates.sort(key=lambda x: x[0], reverse=True)
    _, path, version = candidates[0]
    return path, version


def patch_google_maps(text):
    """Install the 2.0.8+ authoritative Google location binding idempotently."""
    new_google = '''    def _google_links(business, settings):\n        # Build one authoritative Google location from the data NORTHBROWN already has.\n        def clean(value):\n            return str(value or '').strip()\n\n        name = clean(business.get('name'))\n        address = clean(business.get('address'))\n        town = clean(business.get('town'))\n        postcode = clean(business.get('postcode') or business.get('postal_code') or business.get('post_code') or business.get('zip'))\n        pid = clean(business.get('google_place_id'))\n\n        # De-duplicate overlapping fields (formatted Google addresses often already contain town/postcode).\n        parts = []\n        seen = set()\n        for value in (name, address, town, postcode):\n            key = re.sub(r'\\s+', ' ', value).strip().lower()\n            if value and key not in seen:\n                parts.append(value); seen.add(key)\n        query = ', '.join(parts)\n        q = quote_plus(query)\n\n        maps = f'https://www.google.com/maps/search/?api=1&query={q}' if q else ''\n        if maps and pid:\n            maps += '&query_place_id=' + quote_plus(pid)\n        directions = f'https://www.google.com/maps/dir/?api=1&destination={q}' if q else ''\n        if directions and pid:\n            directions += '&destination_place_id=' + quote_plus(pid)\n\n        # Free mode links users to the live Google listing. Written review text is not copied.\n        reviews = maps\n        embed_key = clean(settings.get('google_maps_embed_api_key'))\n        embed = ''\n        has_location = bool(pid or address or town or postcode)\n        if embed_key and pid:\n            target = quote_plus('place_id:' + pid)\n            embed = f'https://www.google.com/maps/embed/v1/place?key={quote_plus(embed_key)}&q={target}&zoom=15'\n        elif embed_key and q and has_location:\n            embed = f'https://www.google.com/maps/embed/v1/place?key={quote_plus(embed_key)}&q={q}&zoom=15'\n        return {'maps_url':maps,'directions_url':directions,'reviews_url':reviews,'embed_url':embed}\n\n\n'''
    pat = re.compile(r"    def _google_links\(business, settings\):\n.*?(?=    # Category intelligence)", re.S)
    text, n = pat.subn(lambda _m: new_google, text, count=1)
    if n != 1:
        raise RuntimeError('Could not safely install the Google Maps location binding.')

    old = "            'town': lead.get('town') or '',\n            'phone':"
    new = "            'town': lead.get('town') or '',\n            'postcode': lead.get('postcode') or lead.get('postal_code') or '',\n            'phone':"
    if old in text:
        text = text.replace(old, new, 1)
    elif "'postcode': lead.get('postcode')" not in text:
        raise RuntimeError('Could not safely preserve postcode data for Google Maps.')

    # Existing projects must rebuild URLs from current settings at preview/export time.
    old_render = "    def _render_page(project, page_slug='home', export=False):\n        b = project.get('business') or {}\n"
    new_render = "    def _render_page(project, page_slug='home', export=False):\n        b = dict(project.get('business') or {})\n        try:\n            b.update(_google_links(b, get_settings()))\n        except Exception:\n            pass\n"
    if old_render in text:
        text = text.replace(old_render, new_render, 1)
    elif "b.update(_google_links(b, get_settings()))" not in text and "b.update(_google_links(b,get_settings()))" not in text:
        raise RuntimeError('Could not safely install render-time Google Maps binding.')
    return text



def fetch_design_dna_overlay():
    encoded = ''
    for name in PARTS:
        req = Request(STAGING + name, headers={'User-Agent':'NORTHBROWN-OTA/2.0.10','Cache-Control':'no-cache'})
        with urlopen(req, timeout=20) as response:
            encoded += response.read().decode('ascii').strip()
    gz = base64.b64decode(encoded, validate=True)
    if hashlib.sha256(gz).hexdigest() != GZ_SHA:
        raise RuntimeError('Design DNA transport verification failed. Nothing was changed.')
    raw = gzip.decompress(gz)
    if hashlib.sha256(raw).hexdigest() != OVERLAY_SHA:
        raise RuntimeError('Design DNA payload verification failed. Nothing was changed.')
    return raw.decode('utf-8')


def patch_design_dna(text, overlay):
    if '# ── NORTHBROWN Design DNA v1' in text:
        return text
    anchor = "    @app.get('/api/builder/projects')\n"
    if anchor not in text:
        raise RuntimeError('Could not locate the Website Builder route anchor for Design DNA.')
    text = text.replace(anchor, overlay + '\n' + anchor, 1)
    required = (
        'DESIGN_DNA_VERSION', '_ai_design_dna', '_dna_enforce_diversity',
        '_render_page = _dna_render_page', 'regenerate-design'
    )
    if not all(x in text for x in required):
        raise RuntimeError('Design DNA validation failed before installation.')
    return text


def bump_version(app_text, base_version):
    pattern = rf"APP_VERSION\s*=\s*(['\"]){re.escape(base_version)}\1"
    app_text, n = re.subn(pattern, "APP_VERSION = '2.0.10'", app_text, count=1)
    if n != 1:
        # If a previous failed attempt left a newer marker in the preserved backup,
        # accept 2.0.9/2.0.8/2.0.7 only; never blindly rewrite an unknown version.
        raise RuntimeError(f'Could not safely update the version marker from {base_version}.')
    return app_text


def main():
    backup, base_version = find_backup()
    overlay = fetch_design_dna_overlay()
    work = Path(tempfile.mkdtemp(prefix='northbrown-210-', dir=str(UPDATES)))
    try:
        for rel in CORE:
            src = backup / rel
            if not src.is_file():
                raise RuntimeError(f'Missing preserved NORTHBROWN {base_version} file: {rel}')
            dst = work / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        app_path = work / 'app.py'
        app_path.write_text(bump_version(app_path.read_text(encoding='utf-8'), base_version), encoding='utf-8')

        builder = work / 'builder_routes.py'
        builder_text = builder.read_text(encoding='utf-8')
        builder_text = patch_google_maps(builder_text)
        builder_text = patch_design_dna(builder_text, overlay)
        builder.write_text(builder_text, encoding='utf-8')
        (work / 'VERSION.txt').write_text(TARGET + '\n', encoding='utf-8')

        # Compile every Python entry point before touching live files.
        subprocess.run(
            [sys.executable, '-m', 'py_compile', str(app_path), str(work / 'feature_routes.py'), str(builder)],
            check=True, capture_output=True
        )

        # Hard feature validation before commit.
        final_builder = builder.read_text(encoding='utf-8')
        checks = (
            '# ── NORTHBROWN Design DNA v1',
            "DESIGN_DNA_VERSION = '1.0'",
            '_render_page = _dna_render_page',
            'regenerate-design',
            "place_id:' + pid",
            '&zoom=15',
            "'postcode': lead.get('postcode')"
        )
        if not all(x in final_builder for x in checks):
            raise RuntimeError('NORTHBROWN 2.0.10 feature validation failed. Nothing was changed.')

        for rel in CORE:
            src = work / rel
            dst = ROOT / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_suffix(dst.suffix + '.new')
            shutil.copy2(src, tmp)
            os.replace(tmp, dst)
        (ROOT / 'VERSION.txt').write_text(TARGET + '\n', encoding='utf-8')

        MARKER.parent.mkdir(parents=True, exist_ok=True)
        MARKER.write_text(json.dumps({
            'installed': TARGET,
            'source_backup': str(backup),
            'source_version': base_version,
            'features': ['google-map-binding', 'design-dna-v1'],
        }), encoding='utf-8')

    finally:
        shutil.rmtree(work, ignore_errors=True)

    if os.getenv('NORTHBROWN_TRANSITION_TEST') == '1':
        print('NORTHBROWN_TRANSITION_TEST_OK')
        return
    os.execv(sys.executable, [sys.executable, str(ROOT / 'app.py')])


if __name__ == '__main__':
    main()
