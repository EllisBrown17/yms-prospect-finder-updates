"""NORTHBROWN 1.4.3 OTA bridge.

Keeps the installed 1.4.x application intact, repairs the official GitHub OTA feed,
and reports the bridge version correctly. The previous app.py is preserved by the
updater in data/updates/backups before this file is installed.
"""
import os
from pathlib import Path

os.environ['NORTHBROWN_UPDATE_MANIFEST_URL'] = 'https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/update.json'
root = Path(__file__).resolve().parent
backups = root / 'data' / 'updates' / 'backups'
candidates = sorted((p / 'app.py' for p in backups.glob('*') if (p / 'app.py').is_file()), reverse=True)
if not candidates:
    raise RuntimeError('NORTHBROWN OTA bridge could not find the preserved application backup.')
legacy = candidates[0]
source = legacy.read_text(encoding='utf-8')
source = source.replace("APP_VERSION = '1.4.0'", "APP_VERSION = '1.4.3'", 1)
source = source.replace("APP_VERSION = '1.4.1'", "APP_VERSION = '1.4.3'", 1)
globals()['__file__'] = str(root / 'app.py')
exec(compile(source, str(legacy), 'exec'), globals(), globals())
