#!/usr/bin/env python3
"""YMS Prospect Finder OTA bridge 4.1.1.

This tiny bootstrap is intentionally used by the updater. The existing full app
was backed up immediately before this file was installed. We restore that known-
good build, bump its version, then relaunch it. This proves the GitHub OTA
channel works without replacing the user's data/settings.
"""
import os, re, sys, time, shutil
from pathlib import Path

TARGET_VERSION = "4.1.1"
APP_DIR = Path(__file__).resolve().parent
if sys.platform == "darwin":
    DATA_DIR = Path.home() / "Library" / "Application Support" / "YMS Prospect Finder V3"
elif os.name == "nt":
    DATA_DIR = Path(os.getenv("APPDATA", Path.home())) / "YMS Prospect Finder V3"
else:
    DATA_DIR = Path.home() / ".yms_prospect_finder_v3"


def fail(message):
    try:
        (DATA_DIR / "update_restart_error.txt").write_text(str(message), encoding="utf-8")
    except Exception:
        pass
    raise SystemExit(str(message))

backups = DATA_DIR / "update-backups"
choices = []
if backups.exists():
    for p in backups.glob("before-" + TARGET_VERSION + "-*"):
        if (p / "server.py").exists() and (p / "index.html").exists():
            try: choices.append((p.stat().st_mtime, p))
            except Exception: pass
if not choices:
    fail("OTA bridge could not find the safe pre-update backup. No user data was changed.")
backup = max(choices, key=lambda x: x[0])[1]
try:
    source = (backup / "server.py").read_text("utf-8")
    source, count = re.subn(r'APP_VERSION\s*=\s*["\'][^"\']+["\']', f'APP_VERSION = "{TARGET_VERSION}"', source, count=1)
    if count != 1:
        fail("OTA bridge could not update the application version safely.")
    tmp = APP_DIR / "server.py.ota-new"
    tmp.write_text(source, encoding="utf-8")
    os.replace(tmp, APP_DIR / "server.py")
    shutil.copy2(backup / "index.html", APP_DIR / "index.html")
    marker = DATA_DIR / "last_ota_update.txt"
    marker.write_text(f"{TARGET_VERSION}\n{time.strftime('%Y-%m-%d %H:%M:%S')}\nGitHub OTA channel active\n", encoding="utf-8")
except Exception as exc:
    fail(exc)

# Replace this bootstrap process with the restored full Prospect Finder.
os.execv(sys.executable, [sys.executable, str(APP_DIR / "server.py")])
