# NORTHBROWN 2.0.7 OTA bridge placeholder. Replaced from verified 2.0.6 backup before launch.
def register_feature_routes(app, g):
    return lambda: None
