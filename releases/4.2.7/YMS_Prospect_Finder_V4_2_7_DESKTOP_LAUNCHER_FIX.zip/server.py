#!/usr/bin/env python3
"""YMS Prospect Finder V4.2.7 — desktop launcher repair OTA.

Keeps the installed V4.2.6 runtime intact, bumps the visible/app version, and
repairs the macOS Desktop launcher so it starts the current local server rather
than an old versioned Downloads path. Uses the updater-created safe backup and
rolls back the runtime files if anything fails.
"""
import os, re, sys, time, shutil, stat
from pathlib import Path

TARGET_VERSION = "4.2.7"
APP_DIR = Path(__file__).resolve().parent
if sys.platform == "darwin":
    DATA_DIR = Path.home() / "Library" / "Application Support" / "YMS Prospect Finder V3"
elif os.name == "nt":
    DATA_DIR = Path(os.getenv("APPDATA", Path.home())) / "YMS Prospect Finder V3"
else:
    DATA_DIR = Path.home() / ".yms_prospect_finder_v3"

backup = None

def fail(message):
    global backup
    msg = str(message)
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "update_restart_error.txt").write_text(msg, encoding="utf-8")
    except Exception:
        pass
    try:
        if backup and (backup / "server.py").exists() and (backup / "index.html").exists():
            shutil.copy2(backup / "server.py", APP_DIR / "server.py")
            shutil.copy2(backup / "index.html", APP_DIR / "index.html")
            os.execv(sys.executable, [sys.executable, str(APP_DIR / "server.py")])
    except Exception:
        pass
    raise SystemExit(msg)


def latest_preupdate_backup():
    backups = DATA_DIR / "update-backups"
    choices = []
    if backups.exists():
        for p in backups.glob("before-" + TARGET_VERSION + "-*"):
            if (p / "server.py").exists() and (p / "index.html").exists():
                try:
                    choices.append((p.stat().st_mtime, p))
                except Exception:
                    pass
    if not choices:
        fail("V4.2.7 could not find the safe pre-update backup. Nothing was changed.")
    return max(choices, key=lambda x: x[0])[1]


def patch_runtime(server_source, html_source):
    server_source, n = re.subn(
        r'APP_VERSION\s*=\s*["\'][^"\']+["\']',
        'APP_VERSION = "4.2.7"',
        server_source,
        count=1,
    )
    if n != 1:
        raise RuntimeError("Could not update APP_VERSION")

    platform = "Mac" if sys.platform == "darwin" else ("Windows" if os.name == "nt" else "Desktop")
    html_source = re.sub(
        r'<title>YMS Prospect Finder V[^<]+ — YMS-Tools</title>',
        f'<title>YMS Prospect Finder V4.2.7 {platform} — YMS-Tools</title>',
        html_source,
        count=1,
    )
    html_source = re.sub(
        r'<b id="versionLabel">Prospect Finder V[^<]+</b>',
        f'<b id="versionLabel">Prospect Finder V4.2.7 {platform}</b>',
        html_source,
        count=1,
    )
    html_source = html_source.replace('id="updateSettingsBadge">V4.2.6<', 'id="updateSettingsBadge">V4.2.7<')
    return server_source, html_source


def write_runtime_pointer():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "runtime_path.txt").write_text(str(APP_DIR), encoding="utf-8")


def repair_macos_launcher():
    if sys.platform != "darwin":
        return "not-applicable"

    desktop = Path.home() / "Desktop"
    desktop.mkdir(parents=True, exist_ok=True)
    target = desktop / "YMS Prospect Finder.app"

    # Preserve an existing/broken launcher instead of deleting it.
    if target.exists():
        stamp = time.strftime("%Y%m%d-%H%M%S")
        old = desktop / f"YMS Prospect Finder OLD {stamp}.app"
        try:
            shutil.move(str(target), str(old))
        except Exception:
            # If Finder has the old bundle busy, remove only after copying it aside.
            try:
                shutil.copytree(target, old)
                shutil.rmtree(target)
            except Exception as exc:
                raise RuntimeError(f"Could not replace the old Desktop launcher: {exc}")

    macos = target / "Contents" / "MacOS"
    resources = target / "Contents" / "Resources"
    macos.mkdir(parents=True, exist_ok=True)
    resources.mkdir(parents=True, exist_ok=True)

    exe = macos / "YMS Prospect Finder"
    launcher = r'''#!/bin/bash
set -u
DATA="$HOME/Library/Application Support/YMS Prospect Finder V3"
LOG="$HOME/Library/Logs/YMS Prospect Finder.log"
PTR="$DATA/runtime_path.txt"
PORT=8765
URL="http://127.0.0.1:$PORT"
mkdir -p "$HOME/Library/Logs"
SERVER=""
if [ -f "$PTR" ]; then
  RUNTIME="$(cat "$PTR" 2>/dev/null || true)"
  if [ -n "$RUNTIME" ] && [ -f "$RUNTIME/server.py" ]; then SERVER="$RUNTIME/server.py"; fi
fi
if [ -z "$SERVER" ]; then
  for CAND in \
    "$HOME/Downloads/YMS_Prospect_Finder_V4_1_0_OTA_UPDATER_MAC/server.py" \
    "$HOME/Applications/YMS Prospect Finder/server.py"; do
    if [ -f "$CAND" ]; then SERVER="$CAND"; break; fi
  done
fi
if [ -z "$SERVER" ]; then
  /usr/bin/osascript -e 'display alert "YMS Prospect Finder" message "The YMS runtime could not be found. Open the current app once from Terminal, then install the latest OTA update." as critical'
  exit 1
fi
if ! /usr/bin/curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then
  /usr/bin/nohup /usr/bin/python3 "$SERVER" >> "$LOG" 2>&1 &
fi
for i in {1..30}; do
  if /usr/bin/curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then
    /usr/bin/open "$URL"
    exit 0
  fi
  /bin/sleep 0.5
done
/usr/bin/open "$URL"
exit 0
'''
    exe.write_text(launcher, encoding="utf-8")
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    plist = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDisplayName</key><string>YMS Prospect Finder</string>
<key>CFBundleExecutable</key><string>YMS Prospect Finder</string>
<key>CFBundleIdentifier</key><string>uk.co.ymstools.prospectfinder.launcher</string>
<key>CFBundleName</key><string>YMS Prospect Finder</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>4.2.7</string>
<key>CFBundleVersion</key><string>427</string>
<key>LSUIElement</key><true/>
</dict></plist>'''
    (target / "Contents" / "Info.plist").write_text(plist, encoding="utf-8")

    # Clear stale quarantine only on the locally-created bundle; ignore failure.
    try:
        os.system('/usr/bin/xattr -dr com.apple.quarantine ' + repr(str(target)) + ' >/dev/null 2>&1')
    except Exception:
        pass
    return str(target)


try:
    backup = latest_preupdate_backup()
    server_source = (backup / "server.py").read_text("utf-8")
    html_source = (backup / "index.html").read_text("utf-8")
    server_source, html_source = patch_runtime(server_source, html_source)
    compile(server_source, "v4.2.7-server.py", "exec")

    # Install runtime first, then repair launcher. Runtime rollback remains available
    # if any subsequent step raises.
    (APP_DIR / "server.py").write_text(server_source, encoding="utf-8")
    (APP_DIR / "index.html").write_text(html_source, encoding="utf-8")
    write_runtime_pointer()
    launcher_result = repair_macos_launcher()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "last_ota_update.txt").write_text(
        "4.2.7\n" + time.strftime('%Y-%m-%d %H:%M:%S') +
        "\nDesktop launcher repair installed\n" + str(launcher_result) + "\n",
        encoding="utf-8",
    )
except Exception as exc:
    fail(exc)

os.execv(sys.executable, [sys.executable, str(APP_DIR / "server.py")])
