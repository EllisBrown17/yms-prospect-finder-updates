# NORTHBROWN 2.0.8 Google Maps location bridge.
# Installed through the normal OTA updater; rebuilds from its 2.0.7 backup.
# Failure is handled by the outer updater rollback.
from pathlib import Path
import json, os, re, shutil, subprocess, sys, tempfile

ROOT = Path(__file__).resolve().parent
UPDATES = ROOT / 'data' / 'updates'
TARGET_VERSION = '2.0.8'
BASE_VERSION = '2.0.7'
MARKER = UPDATES / 'northbrown-2.0.8-maps.done'
CORE = ('app.py','feature_routes.py','builder_routes.py','requirements.txt','templates/index.html','static/app.js','static/app.css')


def find_backup():
    candidates=[]
    backups=UPDATES/'backups'
    if backups.exists():
        for p in backups.iterdir():
            if not p.is_dir():
                continue
            try:
                version=(p/'VERSION.txt').read_text(encoding='utf-8').strip()
                app=p/'app.py'
                if version == BASE_VERSION and app.is_file() and app.stat().st_size > 50000:
                    candidates.append(p)
            except Exception:
                pass
    if not candidates:
        raise RuntimeError('Could not find the updater-created NORTHBROWN 2.0.7 backup. No migration was committed.')
    return sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)[0]


def patch_builder(text):
    new_google = '''    def _google_links(business, settings):\n        # Build one authoritative Google location from the data NORTHBROWN already has.\n        def clean(value):\n            return str(value or '').strip()\n\n        name = clean(business.get('name'))\n        address = clean(business.get('address'))\n        town = clean(business.get('town'))\n        postcode = clean(business.get('postcode') or business.get('postal_code') or business.get('post_code') or business.get('zip'))\n        pid = clean(business.get('google_place_id'))\n\n        # De-duplicate overlapping fields (formatted Google addresses often already contain town/postcode).\n        parts = []\n        seen = set()\n        for value in (name, address, town, postcode):\n            key = re.sub(r'\\s+', ' ', value).strip().lower()\n            if value and key not in seen:\n                parts.append(value); seen.add(key)\n        query = ', '.join(parts)\n        q = quote_plus(query)\n\n        maps = f'https://www.google.com/maps/search/?api=1&query={q}' if q else ''\n        if maps and pid:\n            maps += '&query_place_id=' + quote_plus(pid)\n        directions = f'https://www.google.com/maps/dir/?api=1&destination={q}' if q else ''\n        if directions and pid:\n            directions += '&destination_place_id=' + quote_plus(pid)\n\n        # Free mode links users to the live Google listing. Written review text is not copied.\n        reviews = maps\n        embed_key = clean(settings.get('google_maps_embed_api_key'))\n        embed = ''\n        has_location = bool(pid or address or town or postcode)\n        if embed_key and pid:\n            target = quote_plus('place_id:' + pid)\n            embed = f'https://www.google.com/maps/embed/v1/place?key={quote_plus(embed_key)}&q={target}&zoom=15'\n        elif embed_key and q and has_location:\n            embed = f'https://www.google.com/maps/embed/v1/place?key={quote_plus(embed_key)}&q={q}&zoom=15'\n        return {'maps_url':maps,'directions_url':directions,'reviews_url':reviews,'embed_url':embed}\n\n\n'''
    pat = re.compile(r"    def _google_links\(business, settings\):\n.*?(?=    # Category intelligence)", re.S)
    text, n = pat.subn(lambda _m: new_google, text, count=1)
    if n != 1:
        raise RuntimeError('2.0.8 map patch could not locate _google_links safely.')

    # Preserve postcode when it is present in lead data, without requiring it in older databases.
    old = "            'town': lead.get('town') or '',\n            'phone':"
    new = "            'town': lead.get('town') or '',\n            'postcode': lead.get('postcode') or lead.get('postal_code') or '',\n            'phone':"
    if old in text:
        text = text.replace(old, new, 1)
    elif "'postcode': lead.get('postcode')" not in text:
        raise RuntimeError('2.0.8 map patch could not add postcode binding safely.')

    # Rebuild Google URLs at render/export time. This makes existing projects immediately use a newly saved API key.
    old_render = "    def _render_page(project, page_slug='home', export=False):\n        b = project.get('business') or {}\n"
    new_render = "    def _render_page(project, page_slug='home', export=False):\n        b = dict(project.get('business') or {})\n        try:\n            # Never trust stale URLs saved when the project was first created.\n            b.update(_google_links(b, get_settings()))\n        except Exception:\n            pass\n"
    if old_render in text:
        text = text.replace(old_render, new_render, 1)
    elif "b.update(_google_links(b, get_settings()))" not in text:
        raise RuntimeError('2.0.8 map patch could not add live render-time map binding safely.')
    return text


def main():
    legacy=find_backup()
    work=Path(tempfile.mkdtemp(prefix='northbrown-208-', dir=str(UPDATES)))
    try:
        for rel in CORE:
            src=legacy/rel
            if not src.is_file():
                raise RuntimeError(f'Missing preserved NORTHBROWN 2.0.7 file: {rel}')
            dst=work/rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,dst)

        app_path=work/'app.py'
        app_text=app_path.read_text(encoding='utf-8')
        app_text, changed = re.subn(r"APP_VERSION\s*=\s*(['\"])2\.0\.7\1", "APP_VERSION = '2.0.8'", app_text, count=1)
        if changed != 1:
            raise RuntimeError('Could not safely update the NORTHBROWN version marker from 2.0.7.')
        app_path.write_text(app_text, encoding='utf-8')

        builder=work/'builder_routes.py'
        builder.write_text(patch_builder(builder.read_text(encoding='utf-8')), encoding='utf-8')
        (work/'VERSION.txt').write_text(TARGET_VERSION+'\n', encoding='utf-8')

        # Compile before replacing any live code.
        subprocess.run([sys.executable,'-m','py_compile',str(app_path),str(work/'feature_routes.py'),str(builder)],check=True,capture_output=True)

        for rel in CORE:
            src=work/rel; dst=ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True)
            tmp=dst.with_suffix(dst.suffix+'.new'); shutil.copy2(src,tmp); os.replace(tmp,dst)
        (ROOT/'VERSION.txt').write_text(TARGET_VERSION+'\n', encoding='utf-8')
        MARKER.parent.mkdir(parents=True, exist_ok=True)
        MARKER.write_text(json.dumps({'installed':TARGET_VERSION,'source_backup':str(legacy)}),encoding='utf-8')
    finally:
        shutil.rmtree(work,ignore_errors=True)

    # Used only by our release test; never set by NORTHBROWN itself.
    if os.getenv('NORTHBROWN_TRANSITION_TEST') == '1':
        print('NORTHBROWN_TRANSITION_TEST_OK')
        return
    os.execv(sys.executable,[sys.executable,str(ROOT/'app.py')])


if __name__=='__main__':
    main()
