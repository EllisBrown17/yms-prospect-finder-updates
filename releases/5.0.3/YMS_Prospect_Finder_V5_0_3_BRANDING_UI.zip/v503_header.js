/* V5.0.3 branded header + responsive top UI */
(function(){
  const BRAND_IMAGE='data:image/webp;base64,UklGRmoOAABXRUJQVlA4IF4OAACQOwCdASqwAFgAPqlOnUsmJKKhqNqrUMAVCUAY3Z9zUIzPkLkHqu27XmV8370h7x76AHS7f421e9HfCf8f+o/3Pl+5d+xvUs7z8a/BvgEe2POYiXp+eBPrHxXXkX+m+wN5M3+h5Rf0L/d+wb+wW+1rAZwGWMN4qcuxOjy1Sfy/qPDyPaf4tI18lLAVaNaztgPsOSx44i/bjw4FgEPvYnLJED3FtFEshKdZIjW313kTK3cL3HfdjDdA4Dv5+glf9l6qx7/Yvwhlbz+mivo9D2bj/VfwlAvewLki9VubfozAbbo/N62BhToHvqXZUaJ3gdCJtCVZCxv4Xz+2CorHCa+ksVymt4IugsDYrk3zpY/GdNQwZsGhWAjJiTQc+KTn3U5uSo4d8HJ3S1B2N8JdRqx436FwIBpP5xD2fb3Qm1tOCBdIpwmKPxfgetqf35SvZjim5sCFVSTfCt6RjjWCukwbuoJfyHI5khABAdDhHaP5NoNc9Hi4BZEIPvKLNF55bxRbEaCNDma5sPVOngJldZN3WCosHiQv8+yfXeMxsH3ZYqiE7d87sZULrIroXM2UDqLNNcCW8CxjbdZx5zlQRBika9mZmykgxviVsCD1eGsAaEjbD3vHUFnurwiXwvBKq95Mdlo7tAD9NUO0QU07g4waAiLQcvV06BmS+M+CBFFV8fOmkdwn7Iq3LQCjpyDjFjTfP8X15oq4A+iwXJIfuZKGlCpcN3YNY8+YZS9fHob9ek/E9ehFe7d+sbtEClfL1oZctj/GajaUGYQMwruAUYhG9G2GXhMTTu12vmkzwfUl2GGMNC43IPI21XfvdTGHZks5sCGRI4r15TCdWIU7JmKUD/3PgEG1SP5Pa7FagEZD2KEdgFeML8EsKO3YIWdzSqeI8waxI2T5VMCq4ZY/LTgByfTpq9G4/heV5usqIlkCOPtCiMTBehreHsi+DJKLet4B475SXLqaIe4KtXepxH619Y8yK/yOUNB5+gWpgoD+nJdkxCdosxad11pYJvDMvdm6Ce5Gmot4cCdOXpUPAaM4yY4vVEajvE+8vPlUFPVnh0c3t2m5I5XkMpa80aQHnP31knsWaOzx8uTzYlhPjTb4vPjQF2SqdWABNi5kiokqbe0xEAP7BrP8oBcAGO+bFThv3id5aFKPZMbl7gSNhOeqax2meG5GXDTnYmLqGnZdDalMy9/7bAp1965ZES6KiKmlEJ5bsa9py+Nb8LA341lk5o5Htc7pPaNxh/3We5x/UEU63meCX74Ec5344uQqTsSnIP73SVjHBa+SqPiktL5QLAa/0p3ymptLzwQT40zUFA4jS2wkQ3ymUWzD6GOFDeMrjkYZW8aB1PwQz0IBPCcRjV6l9UxWR8bGnaIvpMW5Nu49BkrjTvsx0Vf0ZvEeAiPFpz4wlA1pE3oGnCO6lq9aXhycjjKyXixRjEkmQwjFCL/VwUGOjpvA5lU6sFLSOPxtBvjhWLHm6WFUtFpmPKXj5edRwCX4E1qoKHOY0WGe3GgBv2vyKGfJJdrlTtbFqkhrhP1nqVp0uwb/zCmmpTtjdJd7CZjgFDOxVXQmtVoA9wgnjL97iF6T20uyCA6MoNsn+YkMSegWhOzox+ZmLVN4td1DU4T1xeE4EXrA+0YPz5j4ppfv9XP5dgjzqDBOYA/+hRCOfLt6GXwKLDn/EfVqS6Oyit+lGCbxZQxX4QLClKUTSFspt6Oz0EwmBeroEH8qX/st/qf8OxJKcu6M0xghqqqK/Updq50VVwViVIloY2CLtK9/s36A1XFG9agBX6/XfKoAVSBpfADxJe6ZnYrhyHAThjMMGN8bXYvu+gqwUug9u+8s/zNxnv0k4WmzOys3EDkZrsqd7u9JO6CZ1r9zFJDrwT1BGswHn73eHkeusi+17jbAmYLm2a9J4oPI0Zk69d5Ho/CbdQH691P3WIxUyI9IIKRhU69Xbvnnm3R/sMnimo7k+ITulmqBPXKN5PmJXNkf8fZ8pgtnFLId6QUEnK2dn7zUtR1eIkaWaMnZLtrhh0gfKh7mJRib9d9KD0cb9jjJ+nRm9Cr5amq4NZ5zuSsbMd1xPDC+zcYKl4oFKswk86TerU8Mr2WB0ykAFgwCeilO66MSAG3Y2rn1iyaXGOLoAWjuys6EYYJu2vYTvqzP5wLfl7KzLX19uh4ICwlM/ZnPeeVhMX8t9AxAtNTcvs6mQsZIm0PQNxv5b1cktb0rR2fTmglWqjnEJni0zqo4XUc2cT9OVA4BjWGmU5ZoSWQGnxmuefgM+PdgwTBaSZLYnUb0lgBX3ECawSyzP+uKIzdqjG3KqR3+A+cEdAff6nH5lH+rKPvZVSjYT457EqdAfTYzN0+2MMEUSGmGkzFVx55+KLo3mymlu4/ePj61UqfZURQdXuz4DPaktT2m4yRYJAdsiuIbT+s3RLBaeLNPsk/UzEuwxQT+H+d7avxCCw94ETq096aer4Ex+QFbOGeonbfALF7RJdKB/L8SLQu44/54A5QdoEAd81Xxw3vC8uObqsw2x3Q0XWUb5Dp1DEaGbsMRG/6pmpSqmjXl4LxCDU07PyLgVX9IFwv/nUpngGrh//A+i4Iiqn/3kMtSKXj3KT0ArFWnnaF7/O4iHBRxGBfcXzpj29qwowqHx12VniVB08X/9x/EVqHWQYKCnPttHLOk12qItLFZ/HofxUmVsEgpr9a+4ipR0LWfnKfqguVY/f1XhPj9tVXexzmhJKOrVNU/LXthb1nc+jqB2x+ZzU3ajbdtpS/odlVu+D8QU3rZ0OR1mAE0habDxMKDfmGFJ/mMHAdY3h6UcYWFhZ/vn/dD0nD40nh2SYiXqmUL4Ww4Ne82r2B4BfJ/+vZlcUOv0vtRDrctpB0hl4Q/SNx5jP9DjI/kQV9j8T/Jk4uGdD84AnhgsP8VbRuzG4vHpX7YGovKu2h0yeRbIAIfGYloS1A4lYmuzHVjS0sZHQFX/nmvRH9r2HLUoQeyDfn+dgRjsz87axwlmJ+FjzNKg2OVqtmz+5XDuGl7eehuFtXRJH5M1skMHjFXgIcA9uS7nyQwu5vuark2Z9yhGdoi5ukaau3rXWbDHvL4AFPOr6C8gyuJixN7Ws+/1edLt+jO2e13FZtYSMBQftwd77f9NEFc/DjJZi2IIOe+RumZez+l5V8nheffgPW0CZkGT0sGaYgMn0Zdh0uq3gCqhV//XYQnOdhWWiX/vHGfi9rZp8ECbQ4RRI6qz6I0/IGQOhMtkQfuTByXnLhTxhIbaMRGBTXG/hmjSUwA7YZsGSdtQYVIUXzcParcqMxUOGBHrFzna/cvm3cEsfbPXmqgbNJ6ZlcxhJIVnI860ybw9WACc8zJ3qxRO5KlAmMzzMH04jEmtbCC6tTfWX85keexRGRQCEqgz+5y7CZ0IIf13GSUZyd/JEPiKtgMOhAFaRw/iMNk/GCzem0qSup43wCP6OZ1mmy7g9yAk8IqfK/gr5julI2hr872BqpbhPvUoOSUxJ/18L2edHnowTZmfmqRIbWjXHcQYScZW0aaCPgwDbQXrBBN1RSemT5AOjjLzUBbYaTgiazo2C4nHFxhBjwO9AS0E5qG5bXUqcGiDUpTdAAgTWV4+eLfb0casLiJQ5bTijezgiMm9Y7d9frQs9H9ejkRWNUJAkG7XphnMRw9wfrtriuYtRCkJxJrMhceuKoaAk6e6RLrg/K4sbrTn2sX5GKX88tnwmiiJdlrBFe+q3n5NQibUa/g5ePGocXW7nGplnnUDEHfHs39cUT5stSH5WedlyffKGsiPg621xv9LqshEV6iyyXXm/6ASL9uWR9N8TL0/5qplyO7PIs8+hLeN7cvbLJlvw3VkSxXPvo2bZKMGDLrXWCfW4BBMeBxVVjyx4amXN7h7f3bkIzOnk8uJmrhbtOpnLM8rBYdw+kf04HoMTebrmZtd5nfEfWTD4PIWNy2F+pm7RUlCAUD3v0Wt3YMW1mmdyrR2bOuGQrstzw/6nGhcuPJSAoYrMPpvoOyMgDQMxZneLpZDx4tCk1MXJqWv6euEmMPd+AyoJKRBScJ+DdBsqY2gvhr1hUJpNLHRcLBnE0YTBwZOAVelJsgXqfpWZXMjIoXOPiUDOV7wrjwemfYoGNNacAKINb7A8V8EanzfNL3BlQBAD7lId1gGaAHHHPaeJwd4DekiTV2simdb5EnggyG2ER09VodWat7akcnyJfn4E6oyddob0L01VkuDj5wZVq2jhblgEh36rcpPs5tYXW0Ebn6WyLb8ON2bHhlvWvqCvum6RJl4FiMd9knQBlZNVMR7ovqKZwMIXQnKhrhelLwM2bv30wyq1FGkYpsuJ/llV+FkoT42+X5i7xChqYLfyD1Qn591OxaLwlRZAhQq+uegDU3C2wHLQIFUd1uD8jhJFZVjgBuIQiTuiNtE9ptOBTZiSSx15yyeiAvNJtqgH4uFUOcX+E+nCdQMnz7+h2bPkVye7dBSwMpX0a6Dd9Fbwj4k9efNHYXYQzMp0uXnZeOObxLMIz4eih5PUARcjQegJjzxsfkPnlDIxeevaK2IfTv4sFV7Mw2LI1xtTVlupVtFSTG3u+B59kEyVYceQHIodE/hGQ9fYc1jXi9enp8Hk41oFL3zN3b0D0Yex0aJ/NbaJDJMKY/5eMzr2VbsnMqAAEQc/bP4BJH96kGdg28p+UEVkZTl3xKCuB0enXJAl6tRJLUS8S1IR4vA6hZ0K8uJOPkJKuLaqynFTQsYxNTtxJsR2fb5fmPseexE6SvqzqBqhxbFzTuS5WP9am13VRaOM/lDrHX3fysv8dRYVCLrrUKApb5IFcncw3vvAermFgDYpwfaJ2uD0emm3fEO9TGUPMFFh7j4DLsjP0ZRsNDR2POD+apSfn5n0/Rl+IaPGmk9IWe8Nxa/NEeAAA=';
  function text(el,value){if(el)el.textContent=value;}
  function boot(){
    const header=document.querySelector('header,.topbar,.appHeader,[data-app-header]');
    if(!header||header.dataset.v503Header==='1')return;
    header.dataset.v503Header='1';header.classList.add('v503Header');
    let brand=header.querySelector('.brand,.branding,.appBrand');
    if(!brand){brand=document.createElement('div');brand.className='brand';header.prepend(brand);}
    brand.classList.add('v503Brand');
    let logo=brand.querySelector('.logo,.brandLogo,.appLogo');
    if(!logo){logo=document.createElement('div');logo.className='logo';brand.prepend(logo);}
    logo.classList.add('v503Logo');
    logo.innerHTML='';
    const image=document.createElement('img');image.src=BRAND_IMAGE;image.alt='YMS-Tools';image.decoding='async';image.draggable=false;logo.appendChild(image);

    let h1=brand.querySelector('h1');
    if(!h1){h1=document.createElement('h1');h1.textContent='YMS Prospect Finder';brand.appendChild(h1);}
    text(h1,'YMS Prospect Finder');
    let copy=h1.parentElement;
    if(copy===brand){
      copy=document.createElement('div');copy.className='v503BrandCopy';
      h1.replaceWith(copy);copy.appendChild(h1);
      const existingSmall=brand.querySelector(':scope > small');if(existingSmall)copy.appendChild(existingSmall);
    } else copy.classList.add('v503BrandCopy');
    let small=copy.querySelector('small');
    if(!small){small=document.createElement('small');copy.appendChild(small);}
    text(small,'Prospecting • product intelligence • outreach');

    const version=document.getElementById('versionLabel');
    if(version){
      version.classList.add('v503VersionPill');
      version.textContent='V5.0.3';
      if(version.closest('header')&&version.parentElement!==copy){
        let vr=copy.querySelector('.v503Version');if(!vr){vr=document.createElement('div');vr.className='v503Version';copy.appendChild(vr);}
        vr.appendChild(version);
      }
    } else if(!copy.querySelector('.v503VersionPill')){
      const vr=document.createElement('div');vr.className='v503Version';
      const pill=document.createElement('span');pill.className='v503VersionPill';pill.textContent='V5.0.3';vr.appendChild(pill);copy.appendChild(vr);
    }

    const actions=header.querySelector('.actions,.headerActions,.topActions');
    if(actions)actions.classList.add('v503Actions');

    // Remove duplicated long brand/version strings from tiny header-only labels while preserving controls and statuses.
    header.querySelectorAll('small,span,b').forEach(el=>{
      if(el===small||el===version||el.closest('.v503Version'))return;
      const t=(el.textContent||'').trim();
      if(/^YMS Prospect Finder V5\.0\.\d+ (Mac|Windows|Desktop) — YMS-Tools$/i.test(t))el.classList.add('v503HeaderNoise');
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(boot,250);
})();
