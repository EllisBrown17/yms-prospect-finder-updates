// V5.0.6 separate CRM workspace + bulk Emailed action
(function(){
  'use strict';
  const selected=new Set();
  const names=new Map();
  let crmRows=[];
  let crmFilter='due';
  let crmSearch='';
  let originalShowTab=null;
  let decorating=false;
  let bulkBusy=false;

  function esc(v){
    try{return typeof v5e==='function'?v5e(String(v??'')):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}catch(_){return String(v??'')}
  }
  function isoLocal(d){
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }
  function today(){return isoLocal(new Date())}
  function addBusinessDays(startIso,n){
    let d=startIso?new Date(startIso+'T12:00:00'):new Date();
    let added=0;
    while(added<n){d.setDate(d.getDate()+1);let wd=d.getDay();if(wd!==0&&wd!==6)added++}
    return isoLocal(d);
  }
  function hasBeenSent(r){return Number(r?.state?.attempts||0)>0}
  function activeForReminder(r){return !['replied','closed','suppressed','qualified'].includes(String(r?.state?.stage||''))}
  function dueKind(r){
    const f=String(r?.state?.next_followup||'');
    if(!f||!activeForReminder(r))return '';
    if(f<today())return 'overdue';
    if(f===today())return 'today';
    return 'waiting';
  }
  function stageLabel(s){
    try{return typeof v5StageLabel==='function'?v5StageLabel(s):String(s||'').replaceAll('_',' ')}catch(_){return String(s||'').replaceAll('_',' ')}
  }
  function statusText(r){
    const s=String(r?.state?.stage||''),k=dueKind(r),f=String(r?.state?.next_followup||'');
    if(s==='replied')return 'Reply received';
    if(k==='overdue')return `Overdue · ${f}`;
    if(k==='today')return 'Follow up today';
    if(k==='waiting')return `Follow up ${f}`;
    if(s==='qualified')return 'Qualified opportunity';
    if(s==='closed')return 'Closed';
    if(s==='suppressed')return 'Do not contact';
    return stageLabel(s||'sent_waiting');
  }
  function lastSent(r){
    const h=(r?.history||[]).slice().reverse();
    const x=h.find(e=>String(e?.type||e?.event||e?.kind||'').toLowerCase().includes('sent'));
    const raw=x?.date||x?.at||x?.created_at||x?.timestamp||'';
    return String(raw).slice(0,10);
  }
  function priority(r){const k=dueKind(r);if(k==='overdue')return 0;if(k==='today')return 1;if(String(r?.state?.stage||'')==='replied')return 2;if(k==='waiting')return 3;return 4}

  function findNavButton(label){
    return [...document.querySelectorAll('button,a,[role="tab"]')].find(e=>(e.textContent||'').trim().replace(/\s+\d+$/,'').toLowerCase()===label.toLowerCase());
  }
  function ensureCrmNav(){
    let btn=document.getElementById('v506CrmNav');
    if(btn)return btn;
    const out=findNavButton('Outreach');if(!out)return null;
    btn=out.cloneNode(false);btn.id='v506CrmNav';btn.textContent='CRM';
    btn.removeAttribute('onclick');btn.removeAttribute('href');btn.setAttribute('type','button');
    btn.addEventListener('click',()=>window.showTab?window.showTab('crm'):showCrm());
    out.insertAdjacentElement('afterend',btn);
    return btn;
  }
  function ensureCrmPage(){
    let page=document.getElementById('crm');if(page)return page;
    const out=document.getElementById('outreach');if(!out)return null;
    page=document.createElement(out.tagName||'section');page.id='crm';page.className=out.className||'';
    page.classList.remove('active','show');page.style.display='none';
    page.innerHTML='<div id="v506CrmRoot" class="v506CrmRoot"><div class="v506Empty">Loading CRM…</div></div>';
    out.insertAdjacentElement('afterend',page);
    return page;
  }
  function hideKnownPages(){
    ['dashboard','discover','prospects','products','outreach','settings'].forEach(id=>{const el=document.getElementById(id);if(el){el.style.display='none';el.classList.remove('active','show')}});
  }
  function setNavActive(){
    const crmBtn=ensureCrmNav();
    [...document.querySelectorAll('button,a,[role="tab"]')].forEach(e=>{if(e!==crmBtn&&e.classList?.contains('active'))e.classList.remove('active')});
    crmBtn?.classList.add('active');
  }
  function showCrm(){
    const page=ensureCrmPage();if(!page)return;
    hideKnownPages();page.style.display='block';page.classList.add('active','show');setNavActive();refreshCrm();
  }
  function wrapShowTab(){
    if(window.showTab?.__v506Wrapped)return;
    if(typeof window.showTab==='function')originalShowTab=window.showTab;
    const wrapped=function(name){
      if(name==='crm'){showCrm();return Promise.resolve()}
      const crm=document.getElementById('crm');if(crm){crm.style.display='none';crm.classList.remove('active','show')}
      return originalShowTab?originalShowTab.apply(this,arguments):undefined;
    };
    wrapped.__v506Wrapped=true;window.showTab=wrapped;
  }

  function crmFiltered(){
    let rows=crmRows.filter(hasBeenSent);
    if(crmFilter==='due')rows=rows.filter(r=>['overdue','today'].includes(dueKind(r)));
    else if(crmFilter==='overdue')rows=rows.filter(r=>dueKind(r)==='overdue');
    else if(crmFilter==='waiting')rows=rows.filter(r=>dueKind(r)==='waiting');
    else if(crmFilter==='replied')rows=rows.filter(r=>String(r?.state?.stage||'')==='replied');
    if(crmSearch){const q=crmSearch.toLowerCase();rows=rows.filter(r=>[r.company,r.email,r.sector,r?.product?.product_name].join(' ').toLowerCase().includes(q))}
    rows.sort((a,b)=>{const pa=priority(a),pb=priority(b);if(pa!==pb)return pa-pb;const da=String(a?.state?.next_followup||'9999'),db=String(b?.state?.next_followup||'9999');if(da!==db)return da.localeCompare(db);return String(a?.company||'').localeCompare(String(b?.company||''))});
    return rows;
  }
  function crmRow(r){
    const st=r.state||{},k=dueKind(r),product=r.product||{};
    return `<div class="v506CrmRow ${esc(k||st.stage||'')}">
      <div class="v506Company"><b>${esc(r.company||'Unknown company')}</b><small>${esc(r.sector||'Uncategorised')}${r.email?' · '+esc(r.email):''}</small></div>
      <div><strong>${esc(statusText(r))}</strong><small>${st.next_followup?'Next: '+esc(st.next_followup):'No follow-up date'}</small></div>
      <div><strong>${Number(st.attempts||0)}</strong><small>email${Number(st.attempts||0)===1?'':'s'} logged${lastSent(r)?' · last '+esc(lastSent(r)):''}</small></div>
      <div><strong>${esc(product.product_name||'—')}</strong><small>ALFRA angle</small></div>
      <div class="v506CrmActions"><button class="btn" data-v506-open="${esc(r.id)}">Company</button><button class="btn primary" data-v506-work="${esc(r.id)}">Email / follow-up</button></div>
    </div>`;
  }
  function renderCrm(){
    const root=document.getElementById('v506CrmRoot');if(!root)return;
    const sent=crmRows.filter(hasBeenSent),over=sent.filter(r=>dueKind(r)==='overdue'),due=sent.filter(r=>dueKind(r)==='today'),waiting=sent.filter(r=>dueKind(r)==='waiting'),replies=sent.filter(r=>String(r?.state?.stage||'')==='replied'),rows=crmFiltered();
    const stat=(k,label,n)=>`<button class="v506Stat ${crmFilter===k?'active':''}" data-v506-filter="${k}"><b>${n}</b><span>${label}</span></button>`;
    root.innerHTML=`
      <div class="v506CrmHead"><div><div class="ey">YMS CRM</div><h1>Sales follow-up</h1><p>Every company you mark <b>Emailed ✓</b> is stored here automatically.</p></div><div class="v506CrmHeadActions"><button class="btn" id="v506CrmRefresh">Refresh</button>${typeof window.v504EnableCrmNotifications==='function'?'<button class="btn" id="v506Notify">Desktop reminders</button>':''}</div></div>
      <div class="v506Stats">${stat('due','Due now',over.length+due.length)}${stat('overdue','Overdue',over.length)}${stat('waiting','Waiting',waiting.length)}${stat('replied','Replies',replies.length)}${stat('all','In CRM',sent.length)}</div>
      <div class="v506CrmToolbar"><input id="v506CrmSearch" value="${esc(crmSearch)}" placeholder="Search company, email, sector or ALFRA product…"><span>${rows.length} shown</span></div>
      <div class="v506CrmLegend"><b>Follow-up rule:</b> first email → 3 working days · first follow-up → 5 · later follow-ups → 10.</div>
      <div class="v506CrmList">${rows.length?rows.slice(0,400).map(crmRow).join(''):'<div class="v506Empty">Nothing in this CRM view.</div>'}</div>`;
    root.querySelectorAll('[data-v506-filter]').forEach(b=>b.addEventListener('click',()=>{crmFilter=b.dataset.v506Filter;renderCrm()}));
    root.querySelector('#v506CrmSearch')?.addEventListener('input',e=>{crmSearch=e.target.value||'';renderCrm()});
    root.querySelector('#v506CrmRefresh')?.addEventListener('click',refreshCrm);
    root.querySelector('#v506Notify')?.addEventListener('click',()=>window.v504EnableCrmNotifications?.());
    root.querySelectorAll('[data-v506-open]').forEach(b=>b.addEventListener('click',()=>window.openD?.(b.dataset.v506Open)));
    root.querySelectorAll('[data-v506-work]').forEach(b=>b.addEventListener('click',()=>window.openOutreachFor?.(b.dataset.v506Work)));
    updateCrmBadge(over.length+due.length);
  }
  async function refreshCrm(){
    if(typeof window.api!=='function')return;
    try{const rows=await window.api('/api/outreach/queue?stage=all');if(Array.isArray(rows))crmRows=rows;renderCrm()}catch(_){const root=document.getElementById('v506CrmRoot');if(root)root.innerHTML='<div class="v506Empty">CRM could not refresh. Reopen YMS and try again.</div>'}
  }
  function updateCrmBadge(n){
    const nav=ensureCrmNav();if(!nav)return;let b=nav.querySelector('.v506Badge');if(!b){b=document.createElement('span');b.className='v506Badge';nav.appendChild(b)}b.textContent=String(n);b.style.display=n?'inline-flex':'none';
  }

  function extractId(el){
    const s=el.getAttribute('onclick')||'';
    let m=s.match(/openD\(\s*['"]([^'"]+)['"]\s*\)/);if(m)return m[1];
    m=s.match(/openOutreachFor\(\s*['"]([^'"]+)['"]\s*\)/);return m?m[1]:'';
  }
  function guessName(el,id){
    let n=el;
    for(let i=0;i<4&&n;i++,n=n.parentElement){
      const cand=n.querySelector?.('h2,h3,h4,strong,b');
      const t=(cand?.textContent||'').trim();if(t&&t.length<120&&!/open|email|select/i.test(t))return t;
    }
    return names.get(id)||'Selected prospect';
  }
  function updateBulkBar(){
    const bar=document.getElementById('v506BulkBar');if(!bar)return;
    const count=selected.size;bar.querySelector('#v506SelectedCount').textContent=`${count} selected`;
    const btn=bar.querySelector('#v506EmailedBtn');btn.disabled=!count||bulkBusy;btn.textContent=bulkBusy?'Adding to CRM…':'Emailed ✓';
    document.querySelectorAll('[data-v506-select]').forEach(c=>{c.checked=selected.has(c.dataset.v506Select)});
  }
  function ensureBulkBar(){
    const page=document.getElementById('prospects');if(!page)return null;
    let bar=document.getElementById('v506BulkBar');if(bar)return bar;
    bar=document.createElement('div');bar.id='v506BulkBar';bar.className='v506BulkBar';
    bar.innerHTML='<div><b>Bulk CRM</b><span id="v506SelectedCount">0 selected</span></div><div class="v506BulkActions"><button class="btn" id="v506SelectVisible">Select visible</button><button class="btn" id="v506ClearSelected">Clear</button><button class="btn primary" id="v506EmailedBtn" disabled>Emailed ✓</button></div>';
    const head=page.querySelector('.v4SectionHead,.sectionHead,.pageHead,h1,h2');
    if(head&&head.parentElement===page)head.insertAdjacentElement('afterend',bar);else page.prepend(bar);
    bar.querySelector('#v506SelectVisible').addEventListener('click',()=>{page.querySelectorAll('[data-v506-select]').forEach(c=>{if(c.offsetParent!==null){selected.add(c.dataset.v506Select);const label=c.closest('label')?.nextElementSibling;void label}});updateBulkBar()});
    bar.querySelector('#v506ClearSelected').addEventListener('click',()=>{selected.clear();updateBulkBar()});
    bar.querySelector('#v506EmailedBtn').addEventListener('click',bulkEmailed);
    return bar;
  }
  function decorateProspects(){
    if(decorating)return;decorating=true;
    try{
      const page=document.getElementById('prospects');if(!page)return;ensureBulkBar();
      const seen=new Set();
      page.querySelectorAll('[onclick]').forEach(el=>{
        const id=extractId(el);if(!id||seen.has(id)||page.querySelector(`[data-v506-select="${CSS.escape(id)}"]`))return;seen.add(id);names.set(id,guessName(el,id));
        const label=document.createElement('label');label.className='v506SelectLabel';label.title='Select for bulk CRM update';
        const cb=document.createElement('input');cb.type='checkbox';cb.dataset.v506Select=id;cb.checked=selected.has(id);
        cb.addEventListener('click',e=>e.stopPropagation());cb.addEventListener('change',e=>{e.stopPropagation();if(cb.checked)selected.add(id);else selected.delete(id);updateBulkBar()});
        label.append(cb,document.createTextNode(' Select'));
        el.insertAdjacentElement('beforebegin',label);
      });
      updateBulkBar();
    }finally{decorating=false}
  }

  async function waitForWorkbench(id,timeout=5000){
    const start=Date.now();
    while(Date.now()-start<timeout){
      const follow=document.getElementById('owFollow');
      const current=(typeof window.v5OutSelected!=='undefined'?window.v5OutSelected:'');
      if(follow&&(!current||current===id))return true;
      await new Promise(r=>setTimeout(r,80));
    }
    return false;
  }
  async function markOneEmailed(id){
    if(typeof window.openOutreachFor!=='function'||typeof window.markOutreachSent!=='function')throw new Error('Outreach controls unavailable');
    const maybe=window.openOutreachFor(id);if(maybe&&typeof maybe.then==='function')await maybe;
    if(!await waitForWorkbench(id))throw new Error('Prospect workbench did not load');
    const existing=crmRows.find(r=>r&&r.id===id);const attempts=Number(existing?.state?.attempts||0);const days=attempts<=0?3:(attempts===1?5:10);
    const follow=document.getElementById('owFollow');if(follow&&!follow.value)follow.value=addBusinessDays(today(),days);
    const sent=document.getElementById('owSentAt');if(sent&&!sent.value)sent.value=today();
    const r=window.markOutreachSent(id);if(r&&typeof r.then==='function')await r;
    await new Promise(res=>setTimeout(res,120));
  }
  async function bulkEmailed(){
    if(bulkBusy||!selected.size)return;bulkBusy=true;updateBulkBar();
    const ids=[...selected],failed=[];let done=0;
    const bar=document.getElementById('v506BulkBar');const count=bar?.querySelector('#v506SelectedCount');
    for(const id of ids){
      try{if(count)count.textContent=`Adding ${done+1} of ${ids.length}…`;await markOneEmailed(id);selected.delete(id)}catch(e){failed.push({id,error:String(e?.message||e)})}done++;
    }
    bulkBusy=false;decorateProspects();await refreshCrm();
    if(failed.length){if(count)count.textContent=`${failed.length} could not be added`;updateBulkBar();alert(`${ids.length-failed.length} added to CRM. ${failed.length} could not be logged — leave those selected and try again.`);return}
    updateBulkBar();showCrm();
  }
  window.v506BulkEmailed=bulkEmailed;
  window.v506RefreshCrm=refreshCrm;

  function boot(){
    ensureCrmPage();ensureCrmNav();wrapShowTab();decorateProspects();refreshCrm();
    const old=document.getElementById('v504CrmDashboard');if(old)old.classList.add('v506LegacyCrmHidden');
    let queued=false;const mo=new MutationObserver(()=>{if(queued)return;queued=true;setTimeout(()=>{queued=false;ensureCrmPage();ensureCrmNav();decorateProspects();const legacy=document.getElementById('v504CrmDashboard');if(legacy)legacy.classList.add('v506LegacyCrmHidden')},120)});
    mo.observe(document.documentElement,{childList:true,subtree:true});
    setInterval(()=>{decorateProspects();refreshCrm()},5*60*1000);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,250));else setTimeout(boot,250);
})();
