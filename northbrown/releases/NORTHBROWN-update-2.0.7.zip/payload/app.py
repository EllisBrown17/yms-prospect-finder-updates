#!/usr/bin/env python3
"""NORTHBROWN 2.0.7 safe OTA bridge.

The existing 2.0.6 updater creates a full rollback backup before this bridge runs.
This bridge reconstructs 2.0.7 from that verified backup plus a SHA-256 checked,
hex-encoded gzip patch hosted on the NORTHBROWN GitHub update channel. No Base64
transport is used. Any error exits non-zero so the 2.0.6 updater restores 2.0.6.
"""
from pathlib import Path
import gzip, hashlib, os, py_compile, shutil, subprocess, sys, tempfile, time
from urllib.request import Request, urlopen

TARGET_VERSION='2.0.7'
BASE_VERSION='2.0.6'
HEX_PARTS=['hexpart00.txt','hexpart01.txt','hexpart02.txt','hexpart03.txt']
GZIP_SHA256='12a315aa83310e9fe3c1d556abaa909089e3f79da93fb1ea81cee2724eddd937'
PATCH_SHA256='df7ac18a78dec3c7cef0a3db10964166b3ceba1d35ba74c5155416417656358c'
DEFAULT_BASE_URL='https://raw.githubusercontent.com/EllisBrown17/yms-prospect-finder-updates/main/northbrown/staging/2.0.7'
ROOT=Path(__file__).resolve().parent
UPDATES=ROOT/'data'/'updates'
BACKUPS=UPDATES/'backups'
BASE_URL=os.getenv('NORTHBROWN_BRIDGE_BASE_URL',DEFAULT_BASE_URL).rstrip('/')


def fail(message):
    print('NORTHBROWN 2.0.7 bridge failed: '+str(message), file=sys.stderr, flush=True)
    raise SystemExit(1)


def newest_backup():
    if not BACKUPS.is_dir(): fail('No OTA rollback backup was found.')
    candidates=[p for p in BACKUPS.iterdir() if p.is_dir() and (p/'app.py').is_file()]
    candidates.sort(key=lambda p:p.stat().st_mtime, reverse=True)
    if not candidates: fail('No usable OTA rollback backup was found.')
    for p in candidates:
        try:
            if (p/'VERSION.txt').read_text().strip()==BASE_VERSION:
                return p
        except Exception:
            pass
    fail('The newest rollback backups are not NORTHBROWN 2.0.6.')


def download_text(name):
    url=BASE_URL+'/'+name
    last=None
    for attempt in range(3):
        try:
            req=Request(url, headers={'User-Agent':'NORTHBROWN-OTA/2.0.7','Cache-Control':'no-cache'})
            with urlopen(req, timeout=25) as r:
                data=r.read(10000)
            text=data.decode('ascii').strip()
            if not text: raise ValueError('empty response')
            return text
        except Exception as exc:
            last=exc
            time.sleep(0.7*(attempt+1))
    fail(f'Could not download {name}: {last}')


def safe_copy_tree(src, dst):
    skip={'.env','.venv','data','northbrown.log','.deps_ready','.chromium_ready','__pycache__'}
    for item in src.rglob('*'):
        rel=item.relative_to(src)
        if any(part in skip for part in rel.parts):
            continue
        target=dst/rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item,target)


def main():
    backup=newest_backup()
    stage=Path(tempfile.mkdtemp(prefix='northbrown-207-', dir=str(UPDATES)))
    try:
        safe_copy_tree(backup,stage)
        hex_text=''.join(download_text(name) for name in HEX_PARTS)
        if len(hex_text)%2: fail('Patch transport length is invalid.')
        try: packed=bytes.fromhex(hex_text)
        except ValueError as exc: fail('Patch transport is not valid hex: '+str(exc))
        if hashlib.sha256(packed).hexdigest()!=GZIP_SHA256:
            fail('Compressed patch SHA-256 verification failed.')
        try: patch=gzip.decompress(packed)
        except Exception as exc: fail('Patch decompression failed: '+str(exc))
        if hashlib.sha256(patch).hexdigest()!=PATCH_SHA256:
            fail('Patch SHA-256 verification failed.')
        patch_bin='/usr/bin/patch' if Path('/usr/bin/patch').exists() else shutil.which('patch')
        if not patch_bin: fail('macOS patch utility is unavailable.')
        proc=subprocess.run([patch_bin,'--batch','-p1','-d',str(stage)], input=patch, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if proc.returncode:
            fail('Patch could not be applied cleanly:\n'+proc.stdout.decode('utf-8','replace')[-2000:])
        if (stage/'VERSION.txt').read_text().strip()!=TARGET_VERSION:
            fail('Patched VERSION.txt is not 2.0.7.')
        app_text=(stage/'app.py').read_text(errors='ignore')
        builder_text=(stage/'builder_routes.py').read_text(errors='ignore')
        required=["APP_VERSION = '2.0.7'", "northbrown-icon-2.0.7.png"]
        if not all(x in app_text for x in required): fail('Patched application version markers are incomplete.')
        for marker in ('def _design_recipe','def _section_order_for','builder_remix','review_samples','google_maps_uri'):
            if marker not in builder_text: fail('Builder verification failed: '+marker)
        for f in ('app.py','feature_routes.py','builder_routes.py'):
            py_compile.compile(str(stage/f), doraise=True)
        safe_copy_tree(stage,ROOT)
        try: os.chmod(ROOT/'START_NORTHBROWN_INTERNAL.sh',0o755)
        except Exception: pass
        if os.getenv('NORTHBROWN_BRIDGE_TEST_ONLY')=='1':
            print('NORTHBROWN_BRIDGE_TEST_OK')
            return
    finally:
        if stage.exists(): shutil.rmtree(stage,ignore_errors=True)
    os.execv(sys.executable,[sys.executable,str(ROOT/'app.py')])

if __name__=='__main__':
    main()
